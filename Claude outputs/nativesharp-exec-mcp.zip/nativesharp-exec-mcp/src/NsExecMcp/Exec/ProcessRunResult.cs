namespace NsExecMcp.Exec
{
    // Outcome of one invocation.
    public class ProcessRunResult
    {
        public int ExitCode { get; set; }

        public string StandardOutput { get; set; }

        public string StandardError { get; set; }

        public bool StandardOutputTruncated { get; set; }

        public bool StandardErrorTruncated { get; set; }

        public bool TimedOut { get; set; }

        public long DurationMilliseconds { get; set; }
    }
}

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Threading;
using NsExecMcp.Sandbox;

namespace NsExecMcp.Exec
{
    // Launches a whitelisted program with an explicit argument vector, a built environment,
    // a timeout and an output ceiling. No shell is involved at any point.
    public class ProcessRunner
    {
        private readonly EnvironmentBuilder environmentBuilder;

        public ProcessRunner(EnvironmentBuilder environmentBuilder)
        {
            this.environmentBuilder = environmentBuilder;
        }

        public ProcessRunResult Run(ExecutionRequest request, ProgramEntry entry)
        {
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = request.ExecutablePath;
            startInfo.WorkingDirectory = request.WorkingDirectory;
            startInfo.UseShellExecute = false;
            startInfo.CreateNoWindow = true;
            startInfo.RedirectStandardOutput = true;
            startInfo.RedirectStandardError = true;
            startInfo.RedirectStandardInput = true;
            startInfo.StandardOutputEncoding = Encoding.UTF8;
            startInfo.StandardErrorEncoding = Encoding.UTF8;

            for (int i = 0; i < request.Arguments.Count; i++)
            {
                startInfo.ArgumentList.Add(request.Arguments[i]);
            }

            startInfo.Environment.Clear();
            Dictionary<string, string> environment = environmentBuilder.Build(entry);

            foreach (KeyValuePair<string, string> pair in environment)
            {
                startInfo.Environment[pair.Key] = pair.Value;
            }

            OutputCollector outputCollector = new OutputCollector(request.MaxOutputBytes);
            OutputCollector errorCollector = new OutputCollector(request.MaxOutputBytes);
            ProcessRunResult result = new ProcessRunResult();
            Stopwatch stopwatch = Stopwatch.StartNew();

            using (Process process = new Process())
            {
                process.StartInfo = startInfo;
                using ManualResetEventSlim outputDone = new ManualResetEventSlim(false);
                using ManualResetEventSlim errorDone = new ManualResetEventSlim(false);

                process.OutputDataReceived += delegate (object sender, DataReceivedEventArgs args)
                {
                    if (args.Data == null)
                    {
                        outputDone.Set();
                        return;
                    }

                    lock (outputCollector)
                    {
                        outputCollector.AppendLine(args.Data);
                    }
                };

                process.ErrorDataReceived += delegate (object sender, DataReceivedEventArgs args)
                {
                    if (args.Data == null)
                    {
                        errorDone.Set();
                        return;
                    }

                    lock (errorCollector)
                    {
                        errorCollector.AppendLine(args.Data);
                    }
                };

                process.Start();
                process.BeginOutputReadLine();
                process.BeginErrorReadLine();

                // The child gets no input at all; closing the pipe avoids a tool waiting forever.
                process.StandardInput.Close();

                int timeoutMilliseconds = request.TimeoutSeconds * 1000;
                bool exited = process.WaitForExit(timeoutMilliseconds);

                if (!exited)
                {
                    result.TimedOut = true;
                    KillTree(process);
                    process.WaitForExit(5000);
                }
                else
                {
                    outputDone.Wait(2000);
                    errorDone.Wait(2000);
                }

                stopwatch.Stop();
                result.DurationMilliseconds = stopwatch.ElapsedMilliseconds;

                try
                {
                    result.ExitCode = process.HasExited ? process.ExitCode : -1;
                }
                catch (InvalidOperationException)
                {
                    result.ExitCode = -1;
                }
            }

            result.StandardOutput = outputCollector.GetText();
            result.StandardError = errorCollector.GetText();
            result.StandardOutputTruncated = outputCollector.Truncated;
            result.StandardErrorTruncated = errorCollector.Truncated;
            return result;
        }

        private static void KillTree(Process process)
        {
            try
            {
                process.Kill(true);
            }
            catch (Exception)
            {
                // The process may have exited between the timeout and the kill.
            }
        }
    }
}

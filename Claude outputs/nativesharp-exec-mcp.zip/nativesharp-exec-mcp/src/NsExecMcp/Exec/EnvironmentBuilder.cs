using System;
using System.Collections.Generic;
using System.IO;
using NsExecMcp.Sandbox;

namespace NsExecMcp.Exec
{
    // Builds the environment of the child process from scratch. Nothing is inherited, so a
    // variable such as PATH or a tool specific override cannot be used to reach outside the jail.
    public class EnvironmentBuilder
    {
        private readonly SandboxConfig config;
        private readonly PathGuard guard;
        private readonly List<string> pathFolders;
        private readonly string tempDirectory;

        public EnvironmentBuilder(SandboxConfig config, PathGuard guard)
        {
            this.config = config;
            this.guard = guard;
            pathFolders = BuildPathFolders();
            tempDirectory = BuildTempDirectory();
        }

        public List<string> PathFolders
        {
            get { return pathFolders; }
        }

        public string TempDirectory
        {
            get { return tempDirectory; }
        }

        private List<string> BuildPathFolders()
        {
            List<string> folders = new List<string>();

            for (int i = 0; i < config.Programs.Count; i++)
            {
                ProgramEntry entry = config.Programs[i];
                string canonical = entry.CanonicalPath;

                if (string.IsNullOrEmpty(canonical))
                {
                    canonical = guard.Canonicalize(entry.Path, null);
                }

                string folder = Path.GetDirectoryName(canonical);
                AddUnique(folders, folder);
            }

            for (int i = 0; i < config.PathFolders.Count; i++)
            {
                ResolvedPath resolved = guard.Require(config.PathFolders[i], null, FolderPermission.Read);
                AddUnique(folders, resolved.FullPath);
            }

            return folders;
        }

        private string BuildTempDirectory()
        {
            if (string.IsNullOrEmpty(config.TempDirectory))
            {
                return null;
            }

            ResolvedPath resolved = guard.Require(config.TempDirectory, null,
                                                  FolderPermission.Read | FolderPermission.Write);

            if (!Directory.Exists(resolved.FullPath))
            {
                Directory.CreateDirectory(resolved.FullPath);
            }

            return resolved.FullPath;
        }

        private static void AddUnique(List<string> folders, string folder)
        {
            if (string.IsNullOrEmpty(folder))
            {
                return;
            }

            for (int i = 0; i < folders.Count; i++)
            {
                if (string.Equals(folders[i], folder, StringComparison.OrdinalIgnoreCase))
                {
                    return;
                }
            }

            folders.Add(folder);
        }

        // Produces the full variable set for one invocation.
        public Dictionary<string, string> Build(ProgramEntry entry)
        {
            Dictionary<string, string> values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

            CopySystemValue(values, "SystemRoot");
            CopySystemValue(values, "windir");
            CopySystemValue(values, "NUMBER_OF_PROCESSORS");
            CopySystemValue(values, "PROCESSOR_ARCHITECTURE");

            string systemRoot;

            if (values.TryGetValue("SystemRoot", out systemRoot) && !string.IsNullOrEmpty(systemRoot))
            {
                // System32 is needed for the loader itself; it is not a folder the child may write to.
                string system32 = Path.Combine(systemRoot, "System32");
                List<string> full = new List<string>(pathFolders);
                full.Add(system32);
                values["PATH"] = string.Join(";", full.ToArray());
            }
            else
            {
                values["PATH"] = string.Join(";", pathFolders.ToArray());
            }

            values["PATHEXT"] = ".EXE";

            if (!string.IsNullOrEmpty(tempDirectory))
            {
                values["TEMP"] = tempDirectory;
                values["TMP"] = tempDirectory;
            }

            foreach (KeyValuePair<string, string> pair in entry.Environment)
            {
                values[pair.Key] = pair.Value;
            }

            return values;
        }

        private static void CopySystemValue(Dictionary<string, string> values, string name)
        {
            string value = Environment.GetEnvironmentVariable(name);

            if (!string.IsNullOrEmpty(value))
            {
                values[name] = value;
            }
        }
    }
}

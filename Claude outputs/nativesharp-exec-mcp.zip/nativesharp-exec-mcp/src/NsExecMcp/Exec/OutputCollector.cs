using System.Text;

namespace NsExecMcp.Exec
{
    // Accumulates one output stream up to a hard ceiling and remembers whether it was cut.
    public class OutputCollector
    {
        private readonly StringBuilder builder;
        private readonly int maxBytes;
        private int byteCount;
        private bool truncated;

        public OutputCollector(int maxBytes)
        {
            this.maxBytes = maxBytes;
            builder = new StringBuilder();
            byteCount = 0;
            truncated = false;
        }

        public bool Truncated
        {
            get { return truncated; }
        }

        public void AppendLine(string line)
        {
            if (line == null)
            {
                return;
            }

            if (truncated)
            {
                return;
            }

            int size = Encoding.UTF8.GetByteCount(line) + 2;

            if (byteCount + size > maxBytes)
            {
                truncated = true;
                return;
            }

            byteCount += size;
            builder.AppendLine(line);
        }

        public string GetText()
        {
            return builder.ToString();
        }
    }
}

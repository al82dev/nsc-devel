using System.Collections.Generic;

namespace NsExecMcp.Exec
{
    // One validated request to run a whitelisted program.
    public class ExecutionRequest
    {
        public ExecutionRequest()
        {
            Arguments = new List<string>();
        }

        // Program id as declared in the configuration.
        public string ProgramId { get; set; }

        // Canonical path of the image actually launched.
        public string ExecutablePath { get; set; }

        // Final argument vector, fixed arguments first.
        public List<string> Arguments { get; private set; }

        // Canonical working directory.
        public string WorkingDirectory { get; set; }

        public int TimeoutSeconds { get; set; }

        public int MaxOutputBytes { get; set; }
    }
}

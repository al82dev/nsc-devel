using System.Collections.Generic;

namespace NsExecMcp.Audit
{
    // One line of the audit log.
    public class AuditEntry
    {
        public AuditEntry()
        {
            Arguments = new List<string>();
        }

        public string TimestampUtc { get; set; }

        public string CallId { get; set; }

        public string Tool { get; set; }

        public string ProgramId { get; set; }

        public string ExecutablePath { get; set; }

        public List<string> Arguments { get; private set; }

        public string WorkingDirectory { get; set; }

        // "ok", "denied" or "error".
        public string Outcome { get; set; }

        public string Reason { get; set; }

        public int ExitCode { get; set; }

        public long DurationMilliseconds { get; set; }

        public bool TimedOut { get; set; }

        public bool OutputTruncated { get; set; }
    }
}

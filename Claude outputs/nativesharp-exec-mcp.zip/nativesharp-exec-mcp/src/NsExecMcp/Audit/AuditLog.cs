using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Json;

namespace NsExecMcp.Audit
{
    // Append only JSON lines log. Every accepted and every rejected call lands here.
    public class AuditLog
    {
        private readonly object gate;
        private readonly string path;

        public AuditLog(string path)
        {
            gate = new object();
            this.path = path;

            // Fully qualified because this class exposes a Path property that hides System.IO.Path.
            string folder = System.IO.Path.GetDirectoryName(path);

            if (!string.IsNullOrEmpty(folder) && !Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }
        }

        public string Path
        {
            get { return path; }
        }

        public void Write(AuditEntry entry)
        {
            string line = Serialize(entry);

            lock (gate)
            {
                try
                {
                    File.AppendAllText(path, line + Environment.NewLine, new UTF8Encoding(false));
                }
                catch (Exception ex)
                {
                    Console.Error.WriteLine("nsexec-mcp: the audit log cannot be written: " + ex.Message);
                }
            }
        }

        private static string Serialize(AuditEntry entry)
        {
            using (MemoryStream stream = new MemoryStream())
            {
                JsonWriterOptions options = new JsonWriterOptions();
                options.Indented = false;

                using (Utf8JsonWriter writer = new Utf8JsonWriter(stream, options))
                {
                    writer.WriteStartObject();
                    writer.WriteString("ts", entry.TimestampUtc);
                    writer.WriteString("callId", entry.CallId);
                    writer.WriteString("tool", entry.Tool);
                    writer.WriteString("program", entry.ProgramId);
                    writer.WriteString("image", entry.ExecutablePath);
                    writer.WriteStartArray("args");

                    for (int i = 0; i < entry.Arguments.Count; i++)
                    {
                        writer.WriteStringValue(entry.Arguments[i]);
                    }

                    writer.WriteEndArray();
                    writer.WriteString("cwd", entry.WorkingDirectory);
                    writer.WriteString("outcome", entry.Outcome);
                    writer.WriteString("reason", entry.Reason);
                    writer.WriteNumber("exitCode", entry.ExitCode);
                    writer.WriteNumber("durationMs", entry.DurationMilliseconds);
                    writer.WriteBoolean("timedOut", entry.TimedOut);
                    writer.WriteBoolean("outputTruncated", entry.OutputTruncated);
                    writer.WriteEndObject();
                }

                return Encoding.UTF8.GetString(stream.ToArray());
            }
        }

        // Returns the last lines of the log, newest last.
        public List<string> ReadTail(int count)
        {
            List<string> lines = new List<string>();

            lock (gate)
            {
                if (!File.Exists(path))
                {
                    return lines;
                }

                using (FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                    {
                        string line = reader.ReadLine();

                        while (line != null)
                        {
                            lines.Add(line);

                            if (lines.Count > count * 4 && lines.Count > 4096)
                            {
                                lines.RemoveRange(0, lines.Count - count);
                            }

                            line = reader.ReadLine();
                        }
                    }
                }
            }

            if (lines.Count > count)
            {
                lines.RemoveRange(0, lines.Count - count);
            }

            return lines;
        }
    }
}

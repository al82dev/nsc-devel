using System;
using System.IO;

namespace NsExecMcp
{
    // Command line options of the executable itself. The MCP client normally passes only --config.
    public class ServerOptions
    {
        public string ConfigFile { get; set; }

        // Validate the configuration, print the policy and exit.
        public bool CheckOnly { get; set; }

        // Show how a path is canonicalized and whether it is authorized.
        public string ProbePath { get; set; }

        // Print the SHA-256 of a file, to fill the configuration.
        public string HashPath { get; set; }

        // Call a tool from the console, for testing without an MCP client.
        public string CallTool { get; set; }

        // JSON arguments of --call.
        public string CallArguments { get; set; }

        public bool ShowHelp { get; set; }

        public static ServerOptions Parse(string[] args)
        {
            ServerOptions options = new ServerOptions();

            for (int i = 0; i < args.Length; i++)
            {
                string argument = args[i];

                if (argument == "--help" || argument == "-h" || argument == "/?")
                {
                    options.ShowHelp = true;
                }
                else if (argument == "--config")
                {
                    options.ConfigFile = ReadValue(args, ref i, argument);
                }
                else if (argument == "--check")
                {
                    options.CheckOnly = true;
                }
                else if (argument == "--probe")
                {
                    options.ProbePath = ReadValue(args, ref i, argument);
                }
                else if (argument == "--hash")
                {
                    options.HashPath = ReadValue(args, ref i, argument);
                }
                else if (argument == "--call")
                {
                    options.CallTool = ReadValue(args, ref i, argument);
                }
                else if (argument == "--json")
                {
                    options.CallArguments = ReadValue(args, ref i, argument);
                }
                else
                {
                    throw new ArgumentException("unknown option: " + argument);
                }
            }

            return options;
        }

        private static string ReadValue(string[] args, ref int index, string name)
        {
            if (index + 1 >= args.Length)
            {
                throw new ArgumentException("the option " + name + " needs a value.");
            }

            index++;
            return args[index];
        }

        public static void PrintUsage(TextWriter output)
        {
            output.WriteLine("nsexec-mcp - MCP stdio server that runs whitelisted programs inside");
            output.WriteLine("authorized folders.");
            output.WriteLine();
            output.WriteLine("Usage:");
            output.WriteLine("  nsexec-mcp --config <file>            Run as an MCP server over stdio.");
            output.WriteLine("  nsexec-mcp --config <file> --check    Validate the policy and print it.");
            output.WriteLine("  nsexec-mcp --config <file> --probe <path>");
            output.WriteLine("                                        Show how a path is canonicalized.");
            output.WriteLine("  nsexec-mcp --hash <file>              Print the SHA-256 of a file.");
            output.WriteLine("  nsexec-mcp --config <file> --call <tool> --json <arguments>");
            output.WriteLine("                                        Call a tool from the console.");
            output.WriteLine();
            output.WriteLine("Without --config the file nsexec-mcp.config.json next to the executable is used.");
        }
    }
}

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using NsExecMcp.Sandbox;

namespace NsExecMcp.Diagnostics
{
    // Explains step by step how a path is canonicalized and why it is accepted or rejected.
    public static class PathProbe
    {
        public static string Describe(PathGuard guard, string rawPath)
        {
            StringBuilder builder = new StringBuilder();
            builder.Append("input: ").Append(rawPath).Append('\n');

            try
            {
                string full = Path.GetFullPath(rawPath);
                builder.Append("getFullPath: ").Append(full).Append('\n');

                string substResolved = WindowsPathResolver.ResolveSubstitutedDrives(full);
                builder.Append("substResolved: ").Append(substResolved).Append('\n');

                string longPath = WindowsPathResolver.GetLongPath(substResolved);
                builder.Append("longName: ").Append(longPath).Append('\n');

                string linkResolved = WindowsPathResolver.ResolveLinks(longPath);
                builder.Append("linksResolved: ").Append(linkResolved).Append('\n');
            }
            catch (Exception ex)
            {
                builder.Append("intermediate step failed: ").Append(ex.Message).Append('\n');
            }

            string canonical = null;

            try
            {
                canonical = guard.Canonicalize(rawPath, null);
                builder.Append("canonical: ").Append(canonical).Append('\n');
            }
            catch (Exception ex)
            {
                builder.Append("canonicalization rejected: ").Append(ex.Message).Append('\n');
                return builder.ToString();
            }

            FileIdentity identity = WindowsPathResolver.GetFileIdentity(canonical);

            if (identity != null)
            {
                builder.Append("identity: ").Append(identity.ToString()).Append('\n');
            }

            SandboxRoot root = guard.FindRoot(canonical);

            if (root == null)
            {
                builder.Append("verdict: outside every authorized folder\n");
                return builder.ToString();
            }

            builder.Append("root: ").Append(root.CanonicalPath).Append('\n');
            builder.Append("permissions: ").Append(root.DescribePermissions()).Append('\n');
            builder.Append("verdict: inside an authorized folder\n");
            return builder.ToString();
        }

        public static string DescribePolicy(PathGuard guard, SandboxConfig config, string auditLogPath)
        {
            StringBuilder builder = new StringBuilder();
            builder.Append("configuration: ").Append(config.SourceFile).Append('\n');
            builder.Append("auditLog: ").Append(auditLogPath).Append('\n');
            builder.Append("defaultTimeoutSeconds: ").Append(config.DefaultTimeoutSeconds).Append('\n');
            builder.Append("maxTimeoutSeconds: ").Append(config.MaxTimeoutSeconds).Append('\n');
            builder.Append("maxOutputBytes: ").Append(config.MaxOutputBytes).Append('\n');
            builder.Append("authorized folders:\n");
            List<string> roots = guard.DescribeRoots();

            for (int i = 0; i < roots.Count; i++)
            {
                builder.Append("  ").Append(roots[i]).Append('\n');
            }

            builder.Append("programs:\n");

            for (int i = 0; i < config.Programs.Count; i++)
            {
                ProgramEntry entry = config.Programs[i];
                builder.Append("  ").Append(entry.Id).Append(" -> ").Append(entry.CanonicalPath).Append('\n');
            }

            return builder.ToString();
        }
    }
}

using System;
using System.IO;
using System.Text.Json;
using NsExecMcp.Audit;
using NsExecMcp.Diagnostics;
using NsExecMcp.Exec;
using NsExecMcp.Mcp;
using NsExecMcp.Sandbox;
using NsExecMcp.Tools;

namespace NsExecMcp
{
    // Entry point. Standard output belongs to the MCP protocol, so every human readable message
    // written outside the server loop goes to standard error.
    public static class Program
    {
        public const string ServerName = "nsexec-mcp";
        public const string ServerVersion = "1.0.0";

        public static int Main(string[] args)
        {
            ServerOptions options;

            try
            {
                options = ServerOptions.Parse(args);
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine(ServerName + ": " + ex.Message);
                return 2;
            }

            if (options.ShowHelp)
            {
                ServerOptions.PrintUsage(Console.Error);
                return 0;
            }

            if (options.HashPath != null)
            {
                return PrintHash(options.HashPath);
            }

            SandboxConfig config;
            PathGuard guard;
            ProgramCatalog catalog;
            AuditLog auditLog;

            try
            {
                config = SandboxConfigLoader.Load(options.ConfigFile);
                guard = new PathGuard(config);
                catalog = new ProgramCatalog(config, guard);
                auditLog = new AuditLog(config.AuditLogPath);
                WarnIfAuditLogIsWritableFromTheJail(config, guard);
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine(ServerName + ": the configuration was rejected: " + ex.Message);
                return 3;
            }

            if (options.ProbePath != null)
            {
                Console.Error.Write(PathProbe.Describe(guard, options.ProbePath));
                return 0;
            }

            if (options.CheckOnly)
            {
                Console.Error.Write(PathProbe.DescribePolicy(guard, config, auditLog.Path));
                Console.Error.WriteLine("policy accepted.");
                return 0;
            }

            EnvironmentBuilder environmentBuilder = new EnvironmentBuilder(config, guard);
            ProcessRunner runner = new ProcessRunner(environmentBuilder);
            ToolRegistry registry = new ToolRegistry();
            registry.Register(new RunProgramTool(config, guard, catalog, runner, auditLog));
            registry.Register(new ListProgramsTool(config));
            registry.Register(new GetPolicyTool(config, guard, auditLog.Path));
            registry.Register(new ReadAuditLogTool(auditLog));

            if (options.CallTool != null)
            {
                return CallFromConsole(registry, options);
            }

            McpServer server = new McpServer(registry, ServerName, ServerVersion);
            return server.Run();
        }

        private static int PrintHash(string path)
        {
            try
            {
                string full = Path.GetFullPath(path);
                Console.Error.WriteLine(ProgramCatalog.ComputeSha256(full) + "  " + full);
                return 0;
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine(ServerName + ": " + ex.Message);
                return 1;
            }
        }

        // The child process runs with the rights of the user, so an audit log living inside a
        // writable authorized folder could be tampered with by whatever was launched.
        private static void WarnIfAuditLogIsWritableFromTheJail(SandboxConfig config, PathGuard guard)
        {
            string canonical;

            try
            {
                canonical = guard.Canonicalize(config.AuditLogPath, null);
            }
            catch (Exception)
            {
                return;
            }

            SandboxRoot root = guard.FindRoot(canonical);

            if (root != null && root.Allows(FolderPermission.Write))
            {
                Console.Error.WriteLine(ServerName + ": warning, the audit log lives inside a writable "
                                        + "authorized folder: " + canonical);
            }
        }

        private static int CallFromConsole(ToolRegistry registry, ServerOptions options)
        {
            IToolHandler handler = registry.Find(options.CallTool);

            if (handler == null)
            {
                Console.Error.WriteLine(ServerName + ": unknown tool: " + options.CallTool);
                return 4;
            }

            JsonElement arguments = default(JsonElement);
            JsonDocument document = null;

            try
            {
                if (options.CallArguments != null)
                {
                    document = JsonDocument.Parse(options.CallArguments);
                    arguments = document.RootElement;
                }

                ToolCallResult result = handler.Invoke(arguments, "console");
                Console.Error.Write(result.Text);

                if (!result.Text.EndsWith("\n", StringComparison.Ordinal))
                {
                    Console.Error.WriteLine();
                }

                return result.IsError ? 1 : 0;
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine(ServerName + ": " + ex.Message);
                return 1;
            }
            finally
            {
                if (document != null)
                {
                    document.Dispose();
                }
            }
        }
    }
}

using System;

namespace NsExecMcp.Mcp
{
    // Raised by a tool when the call itself is wrong, as opposed to the program failing.
    public class ToolException : Exception
    {
        public ToolException(string message) : base(message)
        {
        }
    }
}

using System;
using System.IO;
using System.Text;
using System.Text.Json;

namespace NsExecMcp.Mcp
{
    // Writes newline delimited JSON-RPC messages to standard output. Standard output carries
    // the protocol only; every diagnostic goes to standard error.
    public class JsonRpcWriter
    {
        private readonly object gate;
        private readonly TextWriter writer;

        public JsonRpcWriter(Stream standardOutput)
        {
            gate = new object();
            StreamWriter streamWriter = new StreamWriter(standardOutput, new UTF8Encoding(false));
            streamWriter.AutoFlush = false;
            writer = streamWriter;
        }

        public void WriteRaw(string json)
        {
            lock (gate)
            {
                writer.Write(json);
                writer.Write('\n');
                writer.Flush();
            }
        }

        // Writes a result message for the given request id, taking the result object as raw JSON.
        public void WriteResult(JsonElement id, string resultJson)
        {
            StringBuilder builder = new StringBuilder();
            builder.Append("{\"jsonrpc\":\"2.0\",\"id\":");
            builder.Append(FormatId(id));
            builder.Append(",\"result\":");
            builder.Append(resultJson);
            builder.Append('}');
            WriteRaw(builder.ToString());
        }

        public void WriteError(JsonElement id, int code, string message)
        {
            StringBuilder builder = new StringBuilder();
            builder.Append("{\"jsonrpc\":\"2.0\",\"id\":");
            builder.Append(FormatId(id));
            builder.Append(",\"error\":{\"code\":");
            builder.Append(code.ToString(System.Globalization.CultureInfo.InvariantCulture));
            builder.Append(",\"message\":");
            builder.Append(JsonSerializer.Serialize(message));
            builder.Append("}}");
            WriteRaw(builder.ToString());
        }

        private static string FormatId(JsonElement id)
        {
            if (id.ValueKind == JsonValueKind.Undefined || id.ValueKind == JsonValueKind.Null)
            {
                return "null";
            }

            return id.GetRawText();
        }
    }
}

using System;
using System.Collections.Generic;

namespace NsExecMcp.Mcp
{
    // Holds the tools exposed by the server.
    public class ToolRegistry
    {
        private readonly List<IToolHandler> handlers;

        public ToolRegistry()
        {
            handlers = new List<IToolHandler>();
        }

        public List<IToolHandler> Handlers
        {
            get { return handlers; }
        }

        public void Register(IToolHandler handler)
        {
            handlers.Add(handler);
        }

        public IToolHandler Find(string name)
        {
            for (int i = 0; i < handlers.Count; i++)
            {
                if (string.Equals(handlers[i].Definition.Name, name, StringComparison.Ordinal))
                {
                    return handlers[i];
                }
            }

            return null;
        }
    }
}

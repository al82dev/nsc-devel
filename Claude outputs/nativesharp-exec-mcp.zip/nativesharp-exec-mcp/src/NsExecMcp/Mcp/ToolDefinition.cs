namespace NsExecMcp.Mcp
{
    // Metadata advertised in tools/list.
    public class ToolDefinition
    {
        public ToolDefinition(string name, string title, string description, string inputSchemaJson)
        {
            Name = name;
            Title = title;
            Description = description;
            InputSchemaJson = inputSchemaJson;
        }

        public string Name { get; private set; }

        public string Title { get; private set; }

        public string Description { get; private set; }

        // JSON schema of the arguments, written as a raw JSON string.
        public string InputSchemaJson { get; private set; }
    }
}

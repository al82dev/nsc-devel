namespace NsExecMcp.Mcp
{
    // Text result of a tool call.
    public class ToolCallResult
    {
        public ToolCallResult(string text, bool isError)
        {
            Text = text;
            IsError = isError;
        }

        public string Text { get; private set; }

        // True only when the call could not be performed; a non zero exit code is a valid result.
        public bool IsError { get; private set; }

        public static ToolCallResult Success(string text)
        {
            return new ToolCallResult(text, false);
        }

        public static ToolCallResult Failure(string text)
        {
            return new ToolCallResult(text, true);
        }
    }
}

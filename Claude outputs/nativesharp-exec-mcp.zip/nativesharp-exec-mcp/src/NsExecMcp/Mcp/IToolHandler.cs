using System.Text.Json;

namespace NsExecMcp.Mcp
{
    // Contract implemented by every tool exposed over MCP.
    public interface IToolHandler
    {
        ToolDefinition Definition { get; }

        // arguments is the "arguments" object of tools/call; it may be undefined.
        ToolCallResult Invoke(JsonElement arguments, string callId);
    }
}

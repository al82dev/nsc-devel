using System;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.Json;

namespace NsExecMcp.Mcp
{
    // Minimal MCP server over stdio: newline delimited JSON-RPC 2.0 on standard input and output.
    public class McpServer
    {
        private static readonly string[] SupportedProtocolVersions =
        {
            "2025-06-18", "2025-03-26", "2024-11-05"
        };

        private readonly ToolRegistry registry;
        private readonly JsonRpcWriter writer;
        private readonly string serverName;
        private readonly string serverVersion;
        private long callCounter;

        public McpServer(ToolRegistry registry, string serverName, string serverVersion)
        {
            this.registry = registry;
            this.serverName = serverName;
            this.serverVersion = serverVersion;
            writer = new JsonRpcWriter(Console.OpenStandardOutput());
            callCounter = 0;
        }

        public int Run()
        {
            using (Stream input = Console.OpenStandardInput())
            {
                using (StreamReader reader = new StreamReader(input, new UTF8Encoding(false)))
                {
                    string line = reader.ReadLine();

                    while (line != null)
                    {
                        if (line.Trim().Length > 0)
                        {
                            HandleLine(line);
                        }

                        line = reader.ReadLine();
                    }
                }
            }

            return 0;
        }

        private void HandleLine(string line)
        {
            JsonDocument document;

            try
            {
                document = JsonDocument.Parse(line);
            }
            catch (JsonException ex)
            {
                writer.WriteError(default(JsonElement), JsonRpcErrorCodes.ParseError, ex.Message);
                return;
            }

            using (document)
            {
                JsonElement root = document.RootElement;

                if (root.ValueKind != JsonValueKind.Object)
                {
                    writer.WriteError(default(JsonElement), JsonRpcErrorCodes.InvalidRequest,
                                      "the message must be a JSON object.");
                    return;
                }

                JsonElement idElement;
                bool hasId = root.TryGetProperty("id", out idElement);
                JsonElement methodElement;

                if (!root.TryGetProperty("method", out methodElement)
                    || methodElement.ValueKind != JsonValueKind.String)
                {
                    // A response to something we never sent; nothing to do.
                    return;
                }

                string method = methodElement.GetString();
                JsonElement parameters;

                if (!root.TryGetProperty("params", out parameters))
                {
                    parameters = default(JsonElement);
                }

                try
                {
                    Dispatch(method, parameters, idElement, hasId);
                }
                catch (Exception ex)
                {
                    if (hasId)
                    {
                        writer.WriteError(idElement, JsonRpcErrorCodes.InternalError, ex.Message);
                    }
                    else
                    {
                        Console.Error.WriteLine("nsexec-mcp: " + ex.Message);
                    }
                }
            }
        }

        private void Dispatch(string method, JsonElement parameters, JsonElement id, bool hasId)
        {
            if (method == "initialize")
            {
                writer.WriteResult(id, BuildInitializeResult(parameters));
                return;
            }

            if (method == "ping")
            {
                writer.WriteResult(id, "{}");
                return;
            }

            if (method == "tools/list")
            {
                writer.WriteResult(id, BuildToolListResult());
                return;
            }

            if (method == "tools/call")
            {
                HandleToolCall(parameters, id);
                return;
            }

            if (method.StartsWith("notifications/", StringComparison.Ordinal))
            {
                // Notifications never get a reply.
                return;
            }

            if (hasId)
            {
                writer.WriteError(id, JsonRpcErrorCodes.MethodNotFound, "unknown method: " + method);
            }
        }

        private string BuildInitializeResult(JsonElement parameters)
        {
            string negotiated = SupportedProtocolVersions[0];

            if (parameters.ValueKind == JsonValueKind.Object)
            {
                JsonElement requested;

                if (parameters.TryGetProperty("protocolVersion", out requested)
                    && requested.ValueKind == JsonValueKind.String)
                {
                    string wanted = requested.GetString();

                    for (int i = 0; i < SupportedProtocolVersions.Length; i++)
                    {
                        if (string.Equals(wanted, SupportedProtocolVersions[i], StringComparison.Ordinal))
                        {
                            negotiated = wanted;
                            break;
                        }
                    }
                }
            }

            StringBuilder builder = new StringBuilder();
            builder.Append("{\"protocolVersion\":");
            builder.Append(JsonSerializer.Serialize(negotiated));
            builder.Append(",\"capabilities\":{\"tools\":{\"listChanged\":false}},\"serverInfo\":{\"name\":");
            builder.Append(JsonSerializer.Serialize(serverName));
            builder.Append(",\"version\":");
            builder.Append(JsonSerializer.Serialize(serverVersion));
            builder.Append("}}");
            return builder.ToString();
        }

        private string BuildToolListResult()
        {
            StringBuilder builder = new StringBuilder();
            builder.Append("{\"tools\":[");

            for (int i = 0; i < registry.Handlers.Count; i++)
            {
                ToolDefinition definition = registry.Handlers[i].Definition;

                if (i > 0)
                {
                    builder.Append(',');
                }

                builder.Append("{\"name\":");
                builder.Append(JsonSerializer.Serialize(definition.Name));
                builder.Append(",\"title\":");
                builder.Append(JsonSerializer.Serialize(definition.Title));
                builder.Append(",\"description\":");
                builder.Append(JsonSerializer.Serialize(definition.Description));
                builder.Append(",\"inputSchema\":");
                builder.Append(definition.InputSchemaJson);
                builder.Append('}');
            }

            builder.Append("]}");
            return builder.ToString();
        }

        private void HandleToolCall(JsonElement parameters, JsonElement id)
        {
            if (parameters.ValueKind != JsonValueKind.Object)
            {
                writer.WriteError(id, JsonRpcErrorCodes.InvalidParams, "tools/call needs a params object.");
                return;
            }

            JsonElement nameElement;

            if (!parameters.TryGetProperty("name", out nameElement)
                || nameElement.ValueKind != JsonValueKind.String)
            {
                writer.WriteError(id, JsonRpcErrorCodes.InvalidParams, "tools/call needs a tool name.");
                return;
            }

            string name = nameElement.GetString();
            IToolHandler handler = registry.Find(name);

            if (handler == null)
            {
                writer.WriteError(id, JsonRpcErrorCodes.MethodNotFound, "unknown tool: " + name);
                return;
            }

            JsonElement arguments;

            if (!parameters.TryGetProperty("arguments", out arguments))
            {
                arguments = default(JsonElement);
            }

            callCounter++;
            string callId = callCounter.ToString(CultureInfo.InvariantCulture);
            ToolCallResult result;

            try
            {
                result = handler.Invoke(arguments, callId);
            }
            catch (ToolException ex)
            {
                result = ToolCallResult.Failure(ex.Message);
            }
            catch (Exception ex)
            {
                result = ToolCallResult.Failure(ex.GetType().Name + ": " + ex.Message);
            }

            writer.WriteResult(id, BuildToolCallResult(result));
        }

        private static string BuildToolCallResult(ToolCallResult result)
        {
            StringBuilder builder = new StringBuilder();
            builder.Append("{\"content\":[{\"type\":\"text\",\"text\":");
            builder.Append(JsonSerializer.Serialize(result.Text));
            builder.Append("}],\"isError\":");
            builder.Append(result.IsError ? "true" : "false");
            builder.Append('}');
            return builder.ToString();
        }
    }
}

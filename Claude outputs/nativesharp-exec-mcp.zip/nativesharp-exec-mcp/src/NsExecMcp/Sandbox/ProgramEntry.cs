using System.Collections.Generic;

namespace NsExecMcp.Sandbox
{
    // One whitelisted executable. The client can only name the id, never a path.
    public class ProgramEntry
    {
        public ProgramEntry()
        {
            FixedArguments = new List<string>();
            AllowArgumentsFromClient = true;
            Environment = new Dictionary<string, string>();
            TimeoutSeconds = 0;
            MaxOutputBytes = 0;
            AcknowledgeInterpreter = false;
        }

        // Name used by the client, for example "nsc".
        public string Id { get; set; }

        // Executable path exactly as written in the configuration file.
        public string Path { get; set; }

        // Canonical path of the image, filled during validation.
        public string CanonicalPath { get; set; }

        // Optional description shown to the client.
        public string Description { get; set; }

        // Arguments always placed before the client arguments.
        public List<string> FixedArguments { get; private set; }

        // When false the client cannot add any argument at all.
        public bool AllowArgumentsFromClient { get; set; }

        // Extra environment variables for this program, merged over the minimal environment.
        public Dictionary<string, string> Environment { get; private set; }

        // Per program timeout; zero means use the global default.
        public int TimeoutSeconds { get; set; }

        // Per program output ceiling; zero means use the global default.
        public int MaxOutputBytes { get; set; }

        // Expected SHA-256 of the image, in hexadecimal. Empty means no pinning.
        public string Sha256 { get; set; }

        // Must be set explicitly to whitelist a known interpreter, and only with fixed arguments.
        public bool AcknowledgeInterpreter { get; set; }

        // Default working directory when the client does not pass one.
        public string DefaultWorkingDirectory { get; set; }
    }
}

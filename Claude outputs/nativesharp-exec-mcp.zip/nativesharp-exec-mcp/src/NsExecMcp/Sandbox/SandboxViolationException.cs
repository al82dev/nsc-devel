using System;

namespace NsExecMcp.Sandbox
{
    // Raised when a path, a program or an environment value falls outside the policy.
    public class SandboxViolationException : Exception
    {
        public SandboxViolationException(string message) : base(message)
        {
        }
    }
}

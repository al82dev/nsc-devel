namespace NsExecMcp.Sandbox
{
    // Volume and file index reported by the file system, plus the hard link count.
    public class FileIdentity
    {
        public FileIdentity(uint volumeSerialNumber, ulong fileIndex, uint linkCount)
        {
            VolumeSerialNumber = volumeSerialNumber;
            FileIndex = fileIndex;
            LinkCount = linkCount;
        }

        public uint VolumeSerialNumber { get; private set; }

        public ulong FileIndex { get; private set; }

        // Number of hard links pointing at the same data. More than one means the same bytes
        // are reachable under another path, possibly outside the sandbox.
        public uint LinkCount { get; private set; }

        public bool HasExtraHardLinks
        {
            get { return LinkCount > 1; }
        }

        public override string ToString()
        {
            return "vol=" + VolumeSerialNumber.ToString("X8") + " index=" + FileIndex.ToString("X16")
                   + " links=" + LinkCount.ToString();
        }
    }
}

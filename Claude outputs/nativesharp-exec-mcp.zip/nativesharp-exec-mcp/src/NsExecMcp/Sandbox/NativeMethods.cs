using System;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;

namespace NsExecMcp.Sandbox
{
    // Win32 entry points needed to canonicalize paths the way the file system really sees them.
    public static class NativeMethods
    {
        public const uint FileReadAttributes = 0x0080;
        public const uint FileShareRead = 0x00000001;
        public const uint FileShareWrite = 0x00000002;
        public const uint FileShareDelete = 0x00000004;
        public const uint OpenExisting = 3;
        public const uint FileFlagBackupSemantics = 0x02000000;
        public const uint FileFlagOpenReparsePoint = 0x00200000;

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern uint GetLongPathNameW(string shortPath, System.Text.StringBuilder longPath,
                                                   uint bufferLength);

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern uint QueryDosDeviceW(string deviceName, System.Text.StringBuilder targetPath,
                                                  uint maxChars);

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern SafeFileHandle CreateFileW(string fileName, uint desiredAccess, uint shareMode,
                                                        IntPtr securityAttributes, uint creationDisposition,
                                                        uint flagsAndAttributes, IntPtr templateFile);

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool GetFileInformationByHandle(SafeFileHandle handle,
                                                             out ByHandleFileInformation information);
    }
}

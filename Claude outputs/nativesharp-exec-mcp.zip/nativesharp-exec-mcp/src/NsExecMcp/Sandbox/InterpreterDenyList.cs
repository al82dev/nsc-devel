using System;
using System.IO;

namespace NsExecMcp.Sandbox
{
    // Executables that turn a path jail into nothing, because they run arbitrary commands.
    // Whitelisting one of them requires fixed arguments and an explicit acknowledgement.
    public static class InterpreterDenyList
    {
        private static readonly string[] Names =
        {
            "cmd", "command", "powershell", "pwsh", "wsl", "wslhost", "bash", "sh", "zsh", "dash",
            "python", "python3", "pythonw", "py", "node", "deno", "bun", "perl", "ruby", "php", "lua",
            "wscript", "cscript", "mshta", "rundll32", "regsvr32", "installutil", "msbuild", "dotnet",
            "forfiles", "ftp", "winrs", "psexec", "conhost", "scriptrunner", "explorer", "wmic",
            "certutil", "bitsadmin", "curl", "wget", "schtasks", "at", "reg", "regedit", "sc"
        };

        public static bool IsKnownInterpreter(string executablePath)
        {
            string name = Path.GetFileNameWithoutExtension(executablePath);

            for (int i = 0; i < Names.Length; i++)
            {
                if (string.Equals(name, Names[i], StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }

        // Script files cannot be launched without an interpreter, so they are rejected outright.
        public static bool IsScriptExtension(string executablePath)
        {
            string extension = Path.GetExtension(executablePath);

            if (string.IsNullOrEmpty(extension))
            {
                return false;
            }

            string[] scripts = { ".bat", ".cmd", ".ps1", ".vbs", ".js", ".jse", ".wsf", ".wsh", ".py", ".sh" };

            for (int i = 0; i < scripts.Length; i++)
            {
                if (string.Equals(extension, scripts[i], StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }
    }
}

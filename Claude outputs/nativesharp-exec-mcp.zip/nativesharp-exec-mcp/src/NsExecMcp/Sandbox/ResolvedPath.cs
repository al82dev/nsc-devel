namespace NsExecMcp.Sandbox
{
    // A path that passed every sandbox check.
    public class ResolvedPath
    {
        public ResolvedPath(string fullPath, SandboxRoot root)
        {
            FullPath = fullPath;
            Root = root;
        }

        // Canonical absolute path.
        public string FullPath { get; private set; }

        // Authorized folder that contains it.
        public SandboxRoot Root { get; private set; }
    }
}

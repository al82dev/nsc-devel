using System;
using System.Collections.Generic;
using System.IO;

namespace NsExecMcp.Sandbox
{
    // Single enforcement point for every path used by the server. Nothing touches the file
    // system before going through Canonicalize and the containment check done here.
    public class PathGuard
    {
        private static readonly string[] ReservedDeviceNames =
        {
            "CON", "PRN", "AUX", "NUL",
            "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
            "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9"
        };

        private readonly SandboxConfig config;

        public PathGuard(SandboxConfig config)
        {
            this.config = config;
            CanonicalizeRoots();
        }

        public SandboxConfig Config
        {
            get { return config; }
        }

        private void CanonicalizeRoots()
        {
            if (config.Roots.Count == 0)
            {
                throw new SandboxViolationException("the configuration declares no authorized folder.");
            }

            for (int i = 0; i < config.Roots.Count; i++)
            {
                SandboxRoot root = config.Roots[i];

                if (string.IsNullOrWhiteSpace(root.Path))
                {
                    throw new SandboxViolationException("an authorized folder has an empty path.");
                }

                string canonical = Canonicalize(root.Path, null);
                root.CanonicalPath = canonical;
                root.Exists = Directory.Exists(canonical);
            }

            RejectDuplicatedRoots();
        }

        // Nested folders are allowed and the most specific one wins, so a read only folder can sit
        // inside a writable one and the other way round. Only an exact duplicate is refused.
        private void RejectDuplicatedRoots()
        {
            for (int i = 0; i < config.Roots.Count; i++)
            {
                for (int j = i + 1; j < config.Roots.Count; j++)
                {
                    string first = config.Roots[i].CanonicalPath;
                    string second = config.Roots[j].CanonicalPath;

                    if (string.Equals(first, second, StringComparison.OrdinalIgnoreCase))
                    {
                        throw new SandboxViolationException("the same folder is declared twice: " + first);
                    }
                }
            }
        }

        // Produces the canonical absolute form of a path without checking containment.
        public string Canonicalize(string rawPath, string baseDirectory)
        {
            if (string.IsNullOrWhiteSpace(rawPath))
            {
                throw new SandboxViolationException("an empty path is not valid.");
            }

            string candidate = rawPath.Trim();

            if (candidate.Length > 1 && candidate[0] == '"' && candidate[candidate.Length - 1] == '"')
            {
                candidate = candidate.Substring(1, candidate.Length - 2);
            }

            RejectDangerousSyntax(candidate);
            string expanded = candidate;

            if (!Path.IsPathRooted(expanded))
            {
                if (baseDirectory == null)
                {
                    throw new SandboxViolationException("relative paths are not accepted here: " + rawPath);
                }

                expanded = Path.Combine(baseDirectory, expanded);
            }

            string full = SafeGetFullPath(expanded, rawPath);
            full = WindowsPathResolver.ResolveSubstitutedDrives(full);
            full = SafeGetFullPath(full, rawPath);
            full = ExpandShortNames(full);
            full = WindowsPathResolver.ResolveLinks(full);
            full = WindowsPathResolver.ResolveSubstitutedDrives(full);
            full = SafeGetFullPath(full, rawPath);

            RejectReservedNames(full);
            return TrimTrailingSeparator(full);
        }

        private static string SafeGetFullPath(string path, string original)
        {
            try
            {
                return Path.GetFullPath(path);
            }
            catch (Exception ex)
            {
                throw new SandboxViolationException("invalid path '" + original + "': " + ex.Message);
            }
        }

        // GetLongPathName only works on existing paths, so the deepest existing ancestor is
        // expanded and the missing tail is appended afterwards.
        private static string ExpandShortNames(string fullPath)
        {
            if (!WindowsPathResolver.IsWindows)
            {
                return fullPath;
            }

            if (File.Exists(fullPath) || Directory.Exists(fullPath))
            {
                return WindowsPathResolver.GetLongPath(fullPath);
            }

            List<string> tail = new List<string>();
            string current = fullPath;

            for (int depth = 0; depth < 256; depth++)
            {
                string parent = Path.GetDirectoryName(current);

                if (string.IsNullOrEmpty(parent))
                {
                    return fullPath;
                }

                tail.Insert(0, Path.GetFileName(current));
                current = parent;

                if (Directory.Exists(current))
                {
                    string expandedParent = WindowsPathResolver.GetLongPath(current);
                    string rebuilt = expandedParent;

                    for (int i = 0; i < tail.Count; i++)
                    {
                        rebuilt = Path.Combine(rebuilt, tail[i]);
                    }

                    return rebuilt;
                }
            }

            return fullPath;
        }

        private static void RejectDangerousSyntax(string candidate)
        {
            for (int i = 0; i < candidate.Length; i++)
            {
                if (char.IsControl(candidate[i]))
                {
                    throw new SandboxViolationException("the path contains control characters.");
                }
            }

            if (candidate.StartsWith("\\\\", StringComparison.Ordinal)
                || candidate.StartsWith("//", StringComparison.Ordinal))
            {
                throw new SandboxViolationException("UNC paths are not allowed: " + candidate);
            }

            if (candidate.IndexOf("\\\\?\\", StringComparison.Ordinal) >= 0
                || candidate.IndexOf("\\\\.\\", StringComparison.Ordinal) >= 0)
            {
                throw new SandboxViolationException("extended length or device paths are not allowed: " + candidate);
            }

            if (candidate.IndexOf('*') >= 0 || candidate.IndexOf('?') >= 0)
            {
                throw new SandboxViolationException("wildcards are not allowed in a path: " + candidate);
            }

            // A drive relative path such as X:foo depends on the per drive current directory of
            // the process, which is not something the policy can reason about.
            if (candidate.Length >= 2 && char.IsLetter(candidate[0]) && candidate[1] == ':')
            {
                if (candidate.Length == 2)
                {
                    throw new SandboxViolationException("drive relative paths are not allowed: " + candidate);
                }

                if (candidate[2] != '\\' && candidate[2] != '/')
                {
                    throw new SandboxViolationException("drive relative paths are not allowed: " + candidate);
                }
            }

            int colonIndex = candidate.IndexOf(':');

            while (colonIndex >= 0)
            {
                bool isDriveLetter = colonIndex == 1 && char.IsLetter(candidate[0]);

                if (!isDriveLetter)
                {
                    throw new SandboxViolationException("alternate data streams are not allowed: " + candidate);
                }

                colonIndex = candidate.IndexOf(':', colonIndex + 1);
            }
        }

        private static void RejectReservedNames(string fullPath)
        {
            char[] separators = new char[] { Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar, '\\', '/' };
            string[] parts = fullPath.Split(separators);

            for (int i = 0; i < parts.Length; i++)
            {
                string name = parts[i];
                int dot = name.IndexOf('.');

                if (dot > 0)
                {
                    name = name.Substring(0, dot);
                }

                for (int j = 0; j < ReservedDeviceNames.Length; j++)
                {
                    if (string.Equals(name, ReservedDeviceNames[j], StringComparison.OrdinalIgnoreCase))
                    {
                        throw new SandboxViolationException("reserved device name in the path: " + fullPath);
                    }
                }
            }
        }

        // Canonicalizes and checks that the result sits inside a root holding every required
        // permission. This is the only method commands and tools are meant to call.
        public ResolvedPath Require(string rawPath, string baseDirectory, FolderPermission required)
        {
            string canonical = Canonicalize(rawPath, baseDirectory);
            SandboxRoot root = FindRoot(canonical);

            if (root == null)
            {
                throw new SandboxViolationException("denied, the path is outside the authorized folders: "
                                                    + canonical);
            }

            if (!root.Allows(required))
            {
                throw new SandboxViolationException("denied, the folder lacks the "
                                                    + DescribeRequired(required) + " permission: " + canonical);
            }

            CheckHardLinks(canonical, required);
            return new ResolvedPath(canonical, root);
        }

        // The hard link check exists for data paths: a file inside the jail whose bytes are also
        // reachable under another name outside it. It is not applied to the image of a whitelisted
        // program, because a second hard link does not change which code runs, and several
        // installers legitimately hard link the same executable into more than one folder (Git for
        // Windows ships git.exe in cmd\, bin\ and mingw64\bin\ that way). Integrity of an image is
        // pinned with sha256 instead.
        private void CheckHardLinks(string canonical, FolderPermission required)
        {
            if (config.AllowHardLinkedFiles)
            {
                return;
            }

            if ((required & FolderPermission.Execute) == FolderPermission.Execute)
            {
                return;
            }

            if (!File.Exists(canonical))
            {
                return;
            }

            FileIdentity identity = WindowsPathResolver.GetFileIdentity(canonical);

            if (identity != null && identity.HasExtraHardLinks)
            {
                throw new SandboxViolationException(
                    "denied, the file has more than one hard link and may be reachable outside the "
                    + "authorized folders: " + canonical
                    + ". Set \"allowHardLinkedFiles\": true if this is expected.");
            }
        }

        private static string DescribeRequired(FolderPermission required)
        {
            List<string> names = new List<string>();

            if ((required & FolderPermission.Read) == FolderPermission.Read)
            {
                names.Add("read");
            }

            if ((required & FolderPermission.Write) == FolderPermission.Write)
            {
                names.Add("write");
            }

            if ((required & FolderPermission.Execute) == FolderPermission.Execute)
            {
                names.Add("execute");
            }

            return string.Join("+", names.ToArray());
        }

        public SandboxRoot FindRoot(string canonicalPath)
        {
            SandboxRoot best = null;

            for (int i = 0; i < config.Roots.Count; i++)
            {
                SandboxRoot root = config.Roots[i];

                if (!IsInside(root.CanonicalPath, canonicalPath))
                {
                    continue;
                }

                if (best == null || root.CanonicalPath.Length > best.CanonicalPath.Length)
                {
                    best = root;
                }
            }

            return best;
        }

        public static bool IsInside(string root, string candidate)
        {
            if (string.IsNullOrEmpty(root) || string.IsNullOrEmpty(candidate))
            {
                return false;
            }

            if (string.Equals(root, candidate, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            string prefix = root;
            char separator = Path.DirectorySeparatorChar;

            if (!prefix.EndsWith(separator.ToString(), StringComparison.Ordinal)
                && !prefix.EndsWith("\\", StringComparison.Ordinal))
            {
                prefix = prefix + separator;
            }

            return candidate.StartsWith(prefix, StringComparison.OrdinalIgnoreCase);
        }

        public static string TrimTrailingSeparator(string path)
        {
            if (string.IsNullOrEmpty(path))
            {
                return path;
            }

            string pathRoot = Path.GetPathRoot(path);

            if (string.Equals(path, pathRoot, StringComparison.OrdinalIgnoreCase))
            {
                return path;
            }

            return path.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar, '\\', '/');
        }

        public List<string> DescribeRoots()
        {
            List<string> lines = new List<string>();

            for (int i = 0; i < config.Roots.Count; i++)
            {
                SandboxRoot root = config.Roots[i];
                string state = root.Exists ? "" : "  (missing)";
                lines.Add("[" + root.DescribePermissions() + "] " + root.CanonicalPath + state);
            }

            return lines;
        }
    }
}

namespace NsExecMcp.Sandbox
{
    // One authorized folder and the permissions granted on it.
    public class SandboxRoot
    {
        public SandboxRoot(string path, FolderPermission permissions)
        {
            Path = path;
            Permissions = permissions;
        }

        // Path exactly as written in the configuration file.
        public string Path { get; set; }

        public FolderPermission Permissions { get; set; }

        // Fully canonicalized path: long name, substituted drives and links already resolved.
        public string CanonicalPath { get; set; }

        public bool Exists { get; set; }

        public bool Allows(FolderPermission required)
        {
            return (Permissions & required) == required;
        }

        public string DescribePermissions()
        {
            string text = "";
            text += Allows(FolderPermission.Read) ? "r" : "-";
            text += Allows(FolderPermission.Write) ? "w" : "-";
            text += Allows(FolderPermission.Execute) ? "x" : "-";
            return text;
        }
    }
}

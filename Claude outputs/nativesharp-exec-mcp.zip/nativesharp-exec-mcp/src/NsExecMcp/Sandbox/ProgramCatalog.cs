using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;

namespace NsExecMcp.Sandbox
{
    // Validates the whitelisted programs once at start up and re-checks the image before every run.
    public class ProgramCatalog
    {
        private static readonly string[] ProtectedEnvironmentNames =
        {
            "PATH", "PATHEXT", "COMSPEC", "SYSTEMROOT", "WINDIR", "TEMP", "TMP",
            "__COMPAT_LAYER", "COR_ENABLE_PROFILING", "COR_PROFILER", "DOTNET_STARTUP_HOOKS"
        };

        private readonly SandboxConfig config;
        private readonly PathGuard guard;

        public ProgramCatalog(SandboxConfig config, PathGuard guard)
        {
            this.config = config;
            this.guard = guard;
            ValidateAll();
        }

        public List<ProgramEntry> Programs
        {
            get { return config.Programs; }
        }

        private void ValidateAll()
        {
            for (int i = 0; i < config.Programs.Count; i++)
            {
                Validate(config.Programs[i]);
            }
        }

        private void Validate(ProgramEntry entry)
        {
            ValidateId(entry.Id);

            ResolvedPath image = guard.Require(entry.Path, null, FolderPermission.Read | FolderPermission.Execute);
            entry.CanonicalPath = image.FullPath;

            if (!File.Exists(entry.CanonicalPath))
            {
                throw new SandboxViolationException("the executable does not exist: " + entry.CanonicalPath);
            }

            if (InterpreterDenyList.IsScriptExtension(entry.CanonicalPath))
            {
                throw new SandboxViolationException(
                    "script files cannot be launched directly, they always need an interpreter: "
                    + entry.CanonicalPath);
            }

            if (InterpreterDenyList.IsKnownInterpreter(entry.CanonicalPath))
            {
                if (!entry.AcknowledgeInterpreter)
                {
                    throw new SandboxViolationException(
                        "'" + entry.Id + "' points at a known interpreter, which defeats the jail. Set "
                        + "\"acknowledgeInterpreter\": true, \"allowArgumentsFromClient\": false and fixed "
                        + "arguments if this is really what you want.");
                }

                if (entry.AllowArgumentsFromClient)
                {
                    throw new SandboxViolationException(
                        "'" + entry.Id + "' is an interpreter, so \"allowArgumentsFromClient\" must be false.");
                }

                if (entry.FixedArguments.Count == 0)
                {
                    throw new SandboxViolationException(
                        "'" + entry.Id + "' is an interpreter, so it needs fixed arguments.");
                }
            }

            ValidateFixedArguments(entry);
            ValidateEnvironment(entry);
            ValidateWorkingDirectory(entry);
            ValidateLimits(entry);
            VerifyHash(entry);
        }

        private static void ValidateId(string id)
        {
            if (string.IsNullOrWhiteSpace(id))
            {
                throw new SandboxViolationException("a program id cannot be empty.");
            }

            for (int i = 0; i < id.Length; i++)
            {
                char c = id[i];
                bool valid = char.IsLetterOrDigit(c) || c == '_' || c == '-' || c == '.';

                if (!valid)
                {
                    throw new SandboxViolationException("invalid character in the program id: " + id);
                }
            }
        }

        private void ValidateFixedArguments(ProgramEntry entry)
        {
            for (int i = 0; i < entry.FixedArguments.Count; i++)
            {
                ArgumentValidator.ValidateShape(entry.FixedArguments[i]);
            }
        }

        private void ValidateEnvironment(ProgramEntry entry)
        {
            foreach (KeyValuePair<string, string> pair in entry.Environment)
            {
                string name = pair.Key;

                if (string.IsNullOrWhiteSpace(name))
                {
                    throw new SandboxViolationException("an environment variable has an empty name.");
                }

                for (int i = 0; i < ProtectedEnvironmentNames.Length; i++)
                {
                    if (string.Equals(name, ProtectedEnvironmentNames[i], StringComparison.OrdinalIgnoreCase))
                    {
                        throw new SandboxViolationException(
                            "the environment variable '" + name + "' is built by the server and cannot be "
                            + "set from the configuration.");
                    }
                }

                ArgumentValidator.ValidateShape(pair.Value);
                ValidateEnvironmentValuePaths(entry.Id, name, pair.Value);
            }
        }

        // Any absolute path inside an environment value must stay inside the authorized folders,
        // so a variable cannot point a tool at something outside the jail.
        private void ValidateEnvironmentValuePaths(string programId, string name, string value)
        {
            List<string> candidates = ArgumentValidator.ExtractPathCandidates(value);

            for (int i = 0; i < candidates.Count; i++)
            {
                try
                {
                    guard.Require(candidates[i], null, FolderPermission.Read);
                }
                catch (SandboxViolationException ex)
                {
                    throw new SandboxViolationException("the environment variable '" + name + "' of program '"
                                                        + programId + "' is rejected: " + ex.Message);
                }
            }
        }

        private void ValidateWorkingDirectory(ProgramEntry entry)
        {
            if (string.IsNullOrEmpty(entry.DefaultWorkingDirectory))
            {
                return;
            }

            ResolvedPath resolved = guard.Require(entry.DefaultWorkingDirectory, null, FolderPermission.Read);

            if (!Directory.Exists(resolved.FullPath))
            {
                throw new SandboxViolationException("the default working directory does not exist: "
                                                    + resolved.FullPath);
            }

            entry.DefaultWorkingDirectory = resolved.FullPath;
        }

        private void ValidateLimits(ProgramEntry entry)
        {
            if (entry.TimeoutSeconds < 0 || entry.MaxOutputBytes < 0)
            {
                throw new SandboxViolationException("negative limits in program: " + entry.Id);
            }

            if (entry.TimeoutSeconds > config.MaxTimeoutSeconds)
            {
                throw new SandboxViolationException("the timeout of '" + entry.Id
                                                    + "' is above maxTimeoutSeconds.");
            }
        }

        private void VerifyHash(ProgramEntry entry)
        {
            if (string.IsNullOrWhiteSpace(entry.Sha256))
            {
                return;
            }

            string actual = ComputeSha256(entry.CanonicalPath);

            if (!string.Equals(actual, entry.Sha256.Trim(), StringComparison.OrdinalIgnoreCase))
            {
                throw new SandboxViolationException("the SHA-256 of '" + entry.Id + "' does not match. Expected "
                                                    + entry.Sha256 + ", found " + actual + ".");
            }
        }

        public static string ComputeSha256(string path)
        {
            using (FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                using (SHA256 algorithm = SHA256.Create())
                {
                    byte[] hash = algorithm.ComputeHash(stream);
                    return Convert.ToHexString(hash).ToLowerInvariant();
                }
            }
        }

        // Re-checks the image right before launching, so a swapped binary is caught.
        public ProgramEntry RequireForExecution(string id)
        {
            ProgramEntry entry = config.FindProgram(id);

            if (entry == null)
            {
                throw new SandboxViolationException("unknown program: '" + id + "'. Use the list_programs tool.");
            }

            string canonical = guard.Canonicalize(entry.Path, null);

            if (!string.Equals(canonical, entry.CanonicalPath, StringComparison.OrdinalIgnoreCase))
            {
                throw new SandboxViolationException("the path of '" + id + "' changed since start up.");
            }

            guard.Require(canonical, null, FolderPermission.Read | FolderPermission.Execute);

            if (!File.Exists(canonical))
            {
                throw new SandboxViolationException("the executable disappeared: " + canonical);
            }

            VerifyHash(entry);
            return entry;
        }
    }
}

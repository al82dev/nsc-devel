using System.Collections.Generic;

namespace NsExecMcp.Sandbox
{
    // Whole policy of the server: folders, whitelisted programs and execution ceilings.
    public class SandboxConfig
    {
        public const int DefaultTimeoutSecondsFallback = 120;
        public const int MaxTimeoutSecondsFallback = 900;
        public const int MaxOutputBytesFallback = 262144;

        public SandboxConfig()
        {
            Roots = new List<SandboxRoot>();
            Programs = new List<ProgramEntry>();
            PathFolders = new List<string>();
            DefaultTimeoutSeconds = DefaultTimeoutSecondsFallback;
            MaxTimeoutSeconds = MaxTimeoutSecondsFallback;
            MaxOutputBytes = MaxOutputBytesFallback;
            AllowHardLinkedFiles = false;
        }

        public List<SandboxRoot> Roots { get; private set; }

        public List<ProgramEntry> Programs { get; private set; }

        public int DefaultTimeoutSeconds { get; set; }

        public int MaxTimeoutSeconds { get; set; }

        public int MaxOutputBytes { get; set; }

        // When false a file with more than one hard link is refused.
        public bool AllowHardLinkedFiles { get; set; }

        // Append only JSON lines file with one record per invocation. Required.
        public string AuditLogPath { get; set; }

        // Folders placed in PATH for the child process. They must live inside authorized folders.
        public List<string> PathFolders { get; private set; }

        // Folder used as TEMP and TMP for the child process. Must be writable and authorized.
        public string TempDirectory { get; set; }

        public string SourceFile { get; set; }

        public ProgramEntry FindProgram(string id)
        {
            for (int i = 0; i < Programs.Count; i++)
            {
                if (string.Equals(Programs[i].Id, id, System.StringComparison.Ordinal))
                {
                    return Programs[i];
                }
            }

            return null;
        }
    }
}

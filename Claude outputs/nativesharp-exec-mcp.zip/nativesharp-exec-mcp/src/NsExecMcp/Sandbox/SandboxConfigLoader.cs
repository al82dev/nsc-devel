using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace NsExecMcp.Sandbox
{
    // Reads the policy file. Anything missing or malformed is an error; there are no silent defaults
    // that widen access.
    public static class SandboxConfigLoader
    {
        public const string DefaultFileName = "nsexec-mcp.config.json";

        public static SandboxConfig Load(string explicitFile)
        {
            string file = ResolveFile(explicitFile);
            string text = File.ReadAllText(file);
            SandboxConfig config = new SandboxConfig();
            config.SourceFile = file;

            JsonDocumentOptions options = new JsonDocumentOptions();
            options.AllowTrailingCommas = true;
            options.CommentHandling = JsonCommentHandling.Skip;

            try
            {
                using (JsonDocument document = JsonDocument.Parse(text, options))
                {
                    JsonElement root = document.RootElement;

                    if (root.ValueKind != JsonValueKind.Object)
                    {
                        throw new InvalidDataException("the configuration root must be a JSON object.");
                    }

                    ReadLimits(root, config);
                    ReadRoots(root, config);
                    ReadPrograms(root, config);
                    ReadPathFolders(root, config);
                    ReadAuditLog(root, config, file);
                }
            }
            catch (JsonException ex)
            {
                throw new InvalidDataException("the file is not valid JSON: " + ex.Message
                                               + System.Environment.NewLine + "  file: " + file);
            }
            catch (InvalidDataException ex)
            {
                // Every validation message gets the file name appended, so the reason and the file
                // being read are never guessed from the console.
                throw new InvalidDataException(ex.Message + System.Environment.NewLine + "  file: " + file);
            }

            return config;
        }

        private static string ResolveFile(string explicitFile)
        {
            if (!string.IsNullOrEmpty(explicitFile))
            {
                string full = Path.GetFullPath(explicitFile);

                if (!File.Exists(full))
                {
                    throw new FileNotFoundException("configuration file not found: " + full);
                }

                return full;
            }

            string nextToExe = Path.Combine(AppContext.BaseDirectory, DefaultFileName);

            if (File.Exists(nextToExe))
            {
                return nextToExe;
            }

            throw new FileNotFoundException("configuration file not found: " + nextToExe
                                            + ". Pass --config <file>.");
        }

        private static void ReadLimits(JsonElement root, SandboxConfig config)
        {
            JsonElement element;

            if (root.TryGetProperty("defaultTimeoutSeconds", out element) && element.ValueKind == JsonValueKind.Number)
            {
                config.DefaultTimeoutSeconds = element.GetInt32();
            }

            if (root.TryGetProperty("maxTimeoutSeconds", out element) && element.ValueKind == JsonValueKind.Number)
            {
                config.MaxTimeoutSeconds = element.GetInt32();
            }

            if (root.TryGetProperty("maxOutputBytes", out element) && element.ValueKind == JsonValueKind.Number)
            {
                config.MaxOutputBytes = element.GetInt32();
            }

            if (root.TryGetProperty("allowHardLinkedFiles", out element))
            {
                config.AllowHardLinkedFiles = element.ValueKind == JsonValueKind.True;
            }

            if (config.DefaultTimeoutSeconds <= 0 || config.MaxTimeoutSeconds <= 0)
            {
                throw new InvalidDataException("the timeouts must be greater than zero.");
            }

            if (config.DefaultTimeoutSeconds > config.MaxTimeoutSeconds)
            {
                throw new InvalidDataException("defaultTimeoutSeconds cannot be greater than maxTimeoutSeconds.");
            }

            if (config.MaxOutputBytes < 1024)
            {
                throw new InvalidDataException("maxOutputBytes must be at least 1024.");
            }
        }

        private static void ReadRoots(JsonElement root, SandboxConfig config)
        {
            JsonElement roots;

            if (!root.TryGetProperty("roots", out roots) || roots.ValueKind != JsonValueKind.Array)
            {
                throw new InvalidDataException("the configuration needs a 'roots' array.");
            }

            foreach (JsonElement item in roots.EnumerateArray())
            {
                if (item.ValueKind != JsonValueKind.Object)
                {
                    throw new InvalidDataException("every entry of 'roots' must be an object.");
                }

                JsonElement pathElement;

                if (!item.TryGetProperty("path", out pathElement) || pathElement.ValueKind != JsonValueKind.String)
                {
                    throw new InvalidDataException("every root needs a 'path' string.");
                }

                JsonElement accessElement;

                if (!item.TryGetProperty("access", out accessElement)
                    || accessElement.ValueKind != JsonValueKind.String)
                {
                    throw new InvalidDataException("every root needs an 'access' string such as \"rw\" or \"rx\".");
                }

                FolderPermission permissions = ParsePermissions(accessElement.GetString());
                config.Roots.Add(new SandboxRoot(pathElement.GetString(), permissions));
            }

            if (config.Roots.Count == 0)
            {
                throw new InvalidDataException("'roots' is empty, so every path would be denied. Add at "
                                               + "least one authorized folder.");
            }
        }

        // Accepts the compact form "rwx" and the long form "read,write,execute".
        private static FolderPermission ParsePermissions(string text)
        {
            if (string.IsNullOrWhiteSpace(text))
            {
                throw new InvalidDataException("empty 'access' value.");
            }

            string value = text.Trim().ToLowerInvariant();
            FolderPermission permissions = FolderPermission.None;

            if (value.IndexOf(',') >= 0)
            {
                string[] parts = value.Split(',');

                for (int i = 0; i < parts.Length; i++)
                {
                    string part = parts[i].Trim();

                    if (part == "read")
                    {
                        permissions |= FolderPermission.Read;
                    }
                    else if (part == "write")
                    {
                        permissions |= FolderPermission.Write;
                    }
                    else if (part == "execute")
                    {
                        permissions |= FolderPermission.Execute;
                    }
                    else if (part.Length > 0)
                    {
                        throw new InvalidDataException("unknown permission: " + part);
                    }
                }
            }
            else
            {
                for (int i = 0; i < value.Length; i++)
                {
                    char c = value[i];

                    if (c == 'r')
                    {
                        permissions |= FolderPermission.Read;
                    }
                    else if (c == 'w')
                    {
                        permissions |= FolderPermission.Write;
                    }
                    else if (c == 'x')
                    {
                        permissions |= FolderPermission.Execute;
                    }
                    else if (c != '-')
                    {
                        throw new InvalidDataException("unknown permission letter: " + c);
                    }
                }
            }

            if (permissions == FolderPermission.None)
            {
                throw new InvalidDataException("'access' grants nothing: " + text);
            }

            if ((permissions & FolderPermission.Read) != FolderPermission.Read)
            {
                throw new InvalidDataException("'access' must always include read: " + text);
            }

            return permissions;
        }

        private static void ReadPrograms(JsonElement root, SandboxConfig config)
        {
            JsonElement programs;

            if (!root.TryGetProperty("programs", out programs) || programs.ValueKind != JsonValueKind.Array)
            {
                throw new InvalidDataException("the configuration needs a 'programs' array.");
            }

            foreach (JsonElement item in programs.EnumerateArray())
            {
                if (item.ValueKind != JsonValueKind.Object)
                {
                    throw new InvalidDataException("every entry of 'programs' must be an object.");
                }

                ProgramEntry entry = new ProgramEntry();
                entry.Id = ReadRequiredString(item, "id");
                entry.Path = ReadRequiredString(item, "path");
                entry.Description = ReadOptionalString(item, "description");
                entry.Sha256 = ReadOptionalString(item, "sha256");
                entry.DefaultWorkingDirectory = ReadOptionalString(item, "defaultWorkingDirectory");

                JsonElement element;

                if (item.TryGetProperty("fixedArguments", out element) && element.ValueKind == JsonValueKind.Array)
                {
                    foreach (JsonElement argument in element.EnumerateArray())
                    {
                        if (argument.ValueKind != JsonValueKind.String)
                        {
                            throw new InvalidDataException("'fixedArguments' must contain only strings.");
                        }

                        entry.FixedArguments.Add(argument.GetString());
                    }
                }

                if (item.TryGetProperty("allowArgumentsFromClient", out element))
                {
                    entry.AllowArgumentsFromClient = element.ValueKind != JsonValueKind.False;
                }

                if (item.TryGetProperty("acknowledgeInterpreter", out element))
                {
                    entry.AcknowledgeInterpreter = element.ValueKind == JsonValueKind.True;
                }

                if (item.TryGetProperty("timeoutSeconds", out element) && element.ValueKind == JsonValueKind.Number)
                {
                    entry.TimeoutSeconds = element.GetInt32();
                }

                if (item.TryGetProperty("maxOutputBytes", out element) && element.ValueKind == JsonValueKind.Number)
                {
                    entry.MaxOutputBytes = element.GetInt32();
                }

                if (item.TryGetProperty("environment", out element) && element.ValueKind == JsonValueKind.Object)
                {
                    foreach (JsonProperty property in element.EnumerateObject())
                    {
                        if (property.Value.ValueKind != JsonValueKind.String)
                        {
                            throw new InvalidDataException("'environment' values must be strings.");
                        }

                        entry.Environment[property.Name] = property.Value.GetString();
                    }
                }

                if (config.FindProgram(entry.Id) != null)
                {
                    throw new InvalidDataException("duplicated program id: " + entry.Id);
                }

                config.Programs.Add(entry);
            }

            if (config.Programs.Count == 0)
            {
                throw new InvalidDataException("'programs' is empty, so there is nothing the server could "
                                               + "ever run. Add at least one whitelisted executable "
                                               + "(Programs tab in the editor, or a 'programs' entry with "
                                               + "'id' and 'path').");
            }
        }

        private static void ReadPathFolders(JsonElement root, SandboxConfig config)
        {
            JsonElement element;

            if (root.TryGetProperty("pathFolders", out element) && element.ValueKind == JsonValueKind.Array)
            {
                foreach (JsonElement item in element.EnumerateArray())
                {
                    if (item.ValueKind != JsonValueKind.String)
                    {
                        throw new InvalidDataException("'pathFolders' must contain only strings.");
                    }

                    config.PathFolders.Add(item.GetString());
                }
            }

            if (root.TryGetProperty("tempDirectory", out element) && element.ValueKind == JsonValueKind.String)
            {
                config.TempDirectory = element.GetString();
            }
        }

        private static void ReadAuditLog(JsonElement root, SandboxConfig config, string configFile)
        {
            JsonElement element;

            if (root.TryGetProperty("auditLogPath", out element) && element.ValueKind == JsonValueKind.String)
            {
                config.AuditLogPath = element.GetString();
                return;
            }

            string folder = Path.GetDirectoryName(configFile);
            config.AuditLogPath = Path.Combine(folder, "nsexec-mcp-audit.jsonl");
        }

        private static string ReadRequiredString(JsonElement item, string name)
        {
            JsonElement element;

            if (!item.TryGetProperty(name, out element) || element.ValueKind != JsonValueKind.String)
            {
                throw new InvalidDataException("a program entry needs a '" + name + "' string.");
            }

            string value = element.GetString();

            if (string.IsNullOrWhiteSpace(value))
            {
                throw new InvalidDataException("'" + name + "' cannot be empty.");
            }

            return value;
        }

        private static string ReadOptionalString(JsonElement item, string name)
        {
            JsonElement element;

            if (item.TryGetProperty(name, out element) && element.ValueKind == JsonValueKind.String)
            {
                return element.GetString();
            }

            return null;
        }
    }
}

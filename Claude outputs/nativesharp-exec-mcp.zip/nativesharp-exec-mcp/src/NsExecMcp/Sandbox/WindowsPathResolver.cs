using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Microsoft.Win32.SafeHandles;

namespace NsExecMcp.Sandbox
{
    // Windows specific canonicalization: 8.3 short names, substituted drives, links and file identity.
    public static class WindowsPathResolver
    {
        private const int MaxBuffer = 32768;

        public static bool IsWindows
        {
            get { return OperatingSystem.IsWindows(); }
        }

        // Expands an 8.3 short component such as PROGRA~1 into its long form.
        public static string GetLongPath(string path)
        {
            if (!IsWindows)
            {
                return path;
            }

            try
            {
                StringBuilder buffer = new StringBuilder(MaxBuffer);
                uint length = NativeMethods.GetLongPathNameW(path, buffer, (uint)buffer.Capacity);

                if (length == 0 || length >= buffer.Capacity)
                {
                    return path;
                }

                return buffer.ToString();
            }
            catch (Exception)
            {
                return path;
            }
        }

        // Resolves a drive letter created with 'subst' into the directory it points at.
        // Returns null when the drive is a real volume or cannot be queried.
        public static string GetSubstTarget(char driveLetter)
        {
            if (!IsWindows)
            {
                return null;
            }

            try
            {
                string device = char.ToUpperInvariant(driveLetter) + ":";
                StringBuilder buffer = new StringBuilder(MaxBuffer);
                uint length = NativeMethods.QueryDosDeviceW(device, buffer, (uint)buffer.Capacity);

                if (length == 0)
                {
                    return null;
                }

                string target = buffer.ToString();

                // A substituted drive reports \??\<real path>; a real volume reports \Device\...
                if (!target.StartsWith("\\??\\", StringComparison.Ordinal))
                {
                    return null;
                }

                string inner = target.Substring(4);

                if (inner.Length >= 2 && char.IsLetter(inner[0]) && inner[1] == ':')
                {
                    return inner;
                }

                return null;
            }
            catch (Exception)
            {
                return null;
            }
        }

        // Replaces a substituted drive prefix by its target, following chains of substitutions.
        public static string ResolveSubstitutedDrives(string fullPath)
        {
            string current = fullPath;

            for (int depth = 0; depth < 16; depth++)
            {
                if (current.Length < 2 || !char.IsLetter(current[0]) || current[1] != ':')
                {
                    return current;
                }

                string target = GetSubstTarget(current[0]);

                if (target == null)
                {
                    return current;
                }

                string remainder = current.Substring(2).TrimStart('\\', '/');
                string combined = remainder.Length == 0 ? target : Path.Combine(target, remainder);

                if (string.Equals(combined, current, StringComparison.OrdinalIgnoreCase))
                {
                    return current;
                }

                current = combined;
            }

            throw new SandboxViolationException("too many substituted drives while resolving: " + fullPath);
        }

        // Walks every existing component resolving symbolic links, junctions and mount points.
        public static string ResolveLinks(string fullPath)
        {
            string pathRoot = Path.GetPathRoot(fullPath);

            if (string.IsNullOrEmpty(pathRoot))
            {
                return fullPath;
            }

            string remainder = fullPath.Substring(pathRoot.Length);
            char[] separators = new char[] { Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar, '\\', '/' };
            string[] parts = remainder.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            string current = pathRoot;
            int resolvedLinks = 0;

            for (int i = 0; i < parts.Length; i++)
            {
                current = Path.Combine(current, parts[i]);
                string target = ResolveOneComponent(current, ref resolvedLinks);

                if (target != null)
                {
                    current = target;
                }
            }

            return current;
        }

        private static string ResolveOneComponent(string path, ref int resolvedLinks)
        {
            FileSystemInfo info;

            if (Directory.Exists(path))
            {
                info = new DirectoryInfo(path);
            }
            else if (File.Exists(path))
            {
                info = new FileInfo(path);
            }
            else
            {
                return null;
            }

            if (info.LinkTarget == null)
            {
                return null;
            }

            resolvedLinks++;

            if (resolvedLinks > 32)
            {
                throw new SandboxViolationException("too many links while resolving: " + path);
            }

            FileSystemInfo finalTarget = info.ResolveLinkTarget(true);

            if (finalTarget == null)
            {
                throw new SandboxViolationException("a link in the path cannot be resolved: " + path);
            }

            return finalTarget.FullName;
        }

        // Reads the file identity so hard links to data outside the sandbox can be detected.
        public static FileIdentity GetFileIdentity(string path)
        {
            if (!IsWindows)
            {
                return null;
            }

            uint flags = NativeMethods.FileFlagBackupSemantics;
            SafeFileHandle handle = null;

            try
            {
                handle = NativeMethods.CreateFileW(path, NativeMethods.FileReadAttributes,
                                                   NativeMethods.FileShareRead | NativeMethods.FileShareWrite
                                                   | NativeMethods.FileShareDelete,
                                                   IntPtr.Zero, NativeMethods.OpenExisting, flags, IntPtr.Zero);

                if (handle == null || handle.IsInvalid)
                {
                    return null;
                }

                ByHandleFileInformation information;

                if (!NativeMethods.GetFileInformationByHandle(handle, out information))
                {
                    return null;
                }

                ulong index = ((ulong)information.FileIndexHigh << 32) | information.FileIndexLow;
                return new FileIdentity(information.VolumeSerialNumber, index, information.NumberOfLinks);
            }
            catch (Exception)
            {
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    handle.Dispose();
                }
            }
        }

        // Splits a path into its components, used by the diagnostics output.
        public static List<string> SplitComponents(string fullPath)
        {
            List<string> parts = new List<string>();
            string pathRoot = Path.GetPathRoot(fullPath);

            if (!string.IsNullOrEmpty(pathRoot))
            {
                parts.Add(pathRoot);
            }

            string remainder = fullPath.Substring(pathRoot == null ? 0 : pathRoot.Length);
            char[] separators = new char[] { Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar, '\\', '/' };
            string[] pieces = remainder.Split(separators, StringSplitOptions.RemoveEmptyEntries);

            for (int i = 0; i < pieces.Length; i++)
            {
                parts.Add(pieces[i]);
            }

            return parts;
        }
    }
}

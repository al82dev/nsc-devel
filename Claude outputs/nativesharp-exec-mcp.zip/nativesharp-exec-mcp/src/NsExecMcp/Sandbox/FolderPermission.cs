using System;

namespace NsExecMcp.Sandbox
{
    // Permissions granted on an authorized folder. Execute only allows launching a whitelisted
    // program whose image lives under the folder; it never allows launching anything else.
    [Flags]
    public enum FolderPermission
    {
        None = 0,
        Read = 1,
        Write = 2,
        Execute = 4
    }
}

using System;
using System.Collections.Generic;
using System.IO;

namespace NsExecMcp.Sandbox
{
    // Checks the shape of every argument and keeps the paths inside them within the sandbox.
    // Arguments are passed to the child process one by one, never concatenated into a command line
    // interpreted by a shell.
    public static class ArgumentValidator
    {
        public const int MaxArgumentLength = 8192;
        public const int MaxTotalLength = 32000;

        // Rejects control characters and absurd lengths.
        public static void ValidateShape(string argument)
        {
            if (argument == null)
            {
                throw new SandboxViolationException("an argument is null.");
            }

            if (argument.Length > MaxArgumentLength)
            {
                throw new SandboxViolationException("an argument is longer than " + MaxArgumentLength
                                                    + " characters.");
            }

            for (int i = 0; i < argument.Length; i++)
            {
                char c = argument[i];

                if (char.IsControl(c))
                {
                    throw new SandboxViolationException("an argument contains control characters.");
                }
            }
        }

        public static void ValidateTotalLength(List<string> arguments)
        {
            int total = 0;

            for (int i = 0; i < arguments.Count; i++)
            {
                total += arguments[i].Length + 1;
            }

            if (total > MaxTotalLength)
            {
                throw new SandboxViolationException("the whole argument list is longer than " + MaxTotalLength
                                                    + " characters.");
            }
        }

        // Validates every path that appears inside an argument against the sandbox.
        public static void ValidatePaths(PathGuard guard, string argument, string workingDirectory)
        {
            if (argument.IndexOf("\\\\", StringComparison.Ordinal) >= 0)
            {
                throw new SandboxViolationException("UNC paths are not allowed in an argument: " + argument);
            }

            // A response file makes the tool read a whole argument list from disk.
            if (argument.StartsWith("@", StringComparison.Ordinal) && argument.Length > 1)
            {
                guard.Require(argument.Substring(1), workingDirectory, FolderPermission.Read);
                return;
            }

            List<string> candidates = ExtractPathCandidates(argument);

            for (int i = 0; i < candidates.Count; i++)
            {
                guard.Require(candidates[i], workingDirectory, FolderPermission.Read);
            }

            if (candidates.Count == 0 && LooksLikeRelativePath(argument))
            {
                guard.Require(argument, workingDirectory, FolderPermission.Read);
            }
        }

        // Finds absolute path looking substrings such as C:\foo inside a larger argument.
        public static List<string> ExtractPathCandidates(string text)
        {
            List<string> candidates = new List<string>();

            if (string.IsNullOrEmpty(text))
            {
                return candidates;
            }

            for (int i = 0; i + 2 < text.Length; i++)
            {
                if (!char.IsLetter(text[i]) || text[i + 1] != ':')
                {
                    continue;
                }

                if (i > 0 && !IsBoundary(text[i - 1]))
                {
                    continue;
                }

                if (text[i + 2] != '\\' && text[i + 2] != '/')
                {
                    // A drive relative form such as X:foo is refused rather than guessed, because
                    // it depends on the per drive current directory of the process.
                    throw new SandboxViolationException("drive relative paths are not allowed: " + text);
                }

                int end = text.Length;

                for (int j = i + 3; j < text.Length; j++)
                {
                    char c = text[j];

                    if (c == ';' || c == ',' || c == '"')
                    {
                        end = j;
                        break;
                    }
                }

                candidates.Add(text.Substring(i, end - i));
                i = end;
            }

            return candidates;
        }

        private static bool IsBoundary(char c)
        {
            return c == '=' || c == ':' || c == '"' || c == ';' || c == ',' || c == ' ' || c == '@';
        }

        private static bool LooksLikeRelativePath(string argument)
        {
            if (argument.Length == 0)
            {
                return false;
            }

            if (argument[0] == '-' || argument[0] == '/')
            {
                return false;
            }

            return argument.IndexOf('\\') >= 0 || argument.IndexOf('/') >= 0
                   || Path.GetExtension(argument).Length > 0;
        }
    }
}

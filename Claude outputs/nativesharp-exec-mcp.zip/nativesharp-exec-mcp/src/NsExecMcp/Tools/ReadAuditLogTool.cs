using System.Collections.Generic;
using System.Text;
using System.Text.Json;
using NsExecMcp.Audit;
using NsExecMcp.Mcp;

namespace NsExecMcp.Tools
{
    // Returns the last entries of the audit log.
    public class ReadAuditLogTool : IToolHandler
    {
        private const string Schema =
            "{\"type\":\"object\",\"properties\":{"
            + "\"count\":{\"type\":\"integer\",\"description\":\"How many entries to return, newest last.\"}"
            + "},\"additionalProperties\":false}";

        private const int DefaultCount = 20;
        private const int MaxCount = 200;

        private readonly AuditLog auditLog;
        private readonly ToolDefinition definition;

        public ReadAuditLogTool(AuditLog auditLog)
        {
            this.auditLog = auditLog;
            definition = new ToolDefinition("read_audit_log", "Read the audit log",
                                            "Returns the last invocations recorded by the server, one JSON "
                                            + "object per line.", Schema);
        }

        public ToolDefinition Definition
        {
            get { return definition; }
        }

        public ToolCallResult Invoke(JsonElement arguments, string callId)
        {
            int count = DefaultCount;

            if (arguments.ValueKind == JsonValueKind.Object)
            {
                JsonElement element;

                if (arguments.TryGetProperty("count", out element) && element.ValueKind == JsonValueKind.Number)
                {
                    count = element.GetInt32();
                }
            }

            if (count <= 0)
            {
                count = DefaultCount;
            }

            if (count > MaxCount)
            {
                count = MaxCount;
            }

            List<string> lines = auditLog.ReadTail(count);
            StringBuilder builder = new StringBuilder();
            builder.Append("file: ").Append(auditLog.Path).Append('\n');
            builder.Append("entries: ").Append(lines.Count).Append('\n').Append('\n');

            for (int i = 0; i < lines.Count; i++)
            {
                builder.Append(lines[i]).Append('\n');
            }

            return ToolCallResult.Success(builder.ToString());
        }
    }
}

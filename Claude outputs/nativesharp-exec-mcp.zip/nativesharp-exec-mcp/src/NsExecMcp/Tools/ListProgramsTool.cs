using System.Text;
using System.Text.Json;
using NsExecMcp.Mcp;
using NsExecMcp.Sandbox;

namespace NsExecMcp.Tools
{
    // Lists the whitelisted programs with their fixed arguments and limits.
    public class ListProgramsTool : IToolHandler
    {
        private const string Schema = "{\"type\":\"object\",\"properties\":{},\"additionalProperties\":false}";

        private readonly SandboxConfig config;
        private readonly ToolDefinition definition;

        public ListProgramsTool(SandboxConfig config)
        {
            this.config = config;
            definition = new ToolDefinition("list_programs", "List whitelisted programs",
                                            "Lists every program run_program can start, with its fixed "
                                            + "arguments, default working directory and limits.", Schema);
        }

        public ToolDefinition Definition
        {
            get { return definition; }
        }

        public ToolCallResult Invoke(JsonElement arguments, string callId)
        {
            StringBuilder builder = new StringBuilder();

            for (int i = 0; i < config.Programs.Count; i++)
            {
                ProgramEntry entry = config.Programs[i];
                builder.Append(entry.Id).Append('\n');
                builder.Append("  image: ").Append(entry.CanonicalPath).Append('\n');

                if (!string.IsNullOrEmpty(entry.Description))
                {
                    builder.Append("  description: ").Append(entry.Description).Append('\n');
                }

                if (entry.FixedArguments.Count > 0)
                {
                    builder.Append("  fixedArgs:");

                    for (int j = 0; j < entry.FixedArguments.Count; j++)
                    {
                        builder.Append(' ').Append(JsonSerializer.Serialize(entry.FixedArguments[j]));
                    }

                    builder.Append('\n');
                }

                builder.Append("  acceptsClientArgs: ");
                builder.Append(entry.AllowArgumentsFromClient ? "yes" : "no").Append('\n');

                if (!string.IsNullOrEmpty(entry.DefaultWorkingDirectory))
                {
                    builder.Append("  defaultCwd: ").Append(entry.DefaultWorkingDirectory).Append('\n');
                }

                int timeout = entry.TimeoutSeconds > 0 ? entry.TimeoutSeconds : config.DefaultTimeoutSeconds;
                builder.Append("  timeoutSeconds: ").Append(timeout).Append('\n');
                int maxOutput = entry.MaxOutputBytes > 0 ? entry.MaxOutputBytes : config.MaxOutputBytes;
                builder.Append("  maxOutputBytes: ").Append(maxOutput).Append('\n');
            }

            return ToolCallResult.Success(builder.ToString());
        }
    }
}

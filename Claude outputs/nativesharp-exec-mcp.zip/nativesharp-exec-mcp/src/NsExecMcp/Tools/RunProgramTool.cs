using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.Json;
using NsExecMcp.Audit;
using NsExecMcp.Exec;
using NsExecMcp.Mcp;
using NsExecMcp.Sandbox;

namespace NsExecMcp.Tools
{
    // Runs one whitelisted program with an explicit argument vector and returns exit code,
    // standard output and standard error.
    public class RunProgramTool : IToolHandler
    {
        private const string Schema =
            "{\"type\":\"object\",\"properties\":{"
            + "\"program\":{\"type\":\"string\",\"description\":\"Id of a whitelisted program.\"},"
            + "\"args\":{\"type\":\"array\",\"items\":{\"type\":\"string\"},"
            + "\"description\":\"Arguments passed one by one, never through a shell.\"},"
            + "\"cwd\":{\"type\":\"string\",\"description\":\"Working directory inside an authorized folder.\"},"
            + "\"timeoutSeconds\":{\"type\":\"integer\",\"description\":\"Upper bound for this call.\"}"
            + "},\"required\":[\"program\"],\"additionalProperties\":false}";

        private readonly SandboxConfig config;
        private readonly PathGuard guard;
        private readonly ProgramCatalog catalog;
        private readonly ProcessRunner runner;
        private readonly AuditLog auditLog;
        private readonly ToolDefinition definition;

        public RunProgramTool(SandboxConfig config, PathGuard guard, ProgramCatalog catalog,
                              ProcessRunner runner, AuditLog auditLog)
        {
            this.config = config;
            this.guard = guard;
            this.catalog = catalog;
            this.runner = runner;
            this.auditLog = auditLog;
            definition = new ToolDefinition("run_program", "Run a whitelisted program",
                                            BuildDescription(config), Schema);
        }

        public ToolDefinition Definition
        {
            get { return definition; }
        }

        private static string BuildDescription(SandboxConfig config)
        {
            StringBuilder builder = new StringBuilder();
            builder.Append("Runs one of the whitelisted programs and returns its exit code, standard ");
            builder.Append("output and standard error. Arguments are passed directly to the process, so ");
            builder.Append("operators such as &&, | or > have no meaning. Available programs: ");

            for (int i = 0; i < config.Programs.Count; i++)
            {
                if (i > 0)
                {
                    builder.Append(", ");
                }

                builder.Append(config.Programs[i].Id);
            }

            builder.Append('.');
            return builder.ToString();
        }

        public ToolCallResult Invoke(JsonElement arguments, string callId)
        {
            AuditEntry entry = new AuditEntry();
            entry.TimestampUtc = DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture);
            entry.CallId = callId;
            entry.Tool = definition.Name;

            try
            {
                return Execute(arguments, entry);
            }
            catch (SandboxViolationException ex)
            {
                entry.Outcome = "denied";
                entry.Reason = ex.Message;
                auditLog.Write(entry);
                return ToolCallResult.Failure("denied by the sandbox policy: " + ex.Message);
            }
            catch (ToolException ex)
            {
                entry.Outcome = "error";
                entry.Reason = ex.Message;
                auditLog.Write(entry);
                return ToolCallResult.Failure(ex.Message);
            }
            catch (Exception ex)
            {
                entry.Outcome = "error";
                entry.Reason = ex.Message;
                auditLog.Write(entry);
                return ToolCallResult.Failure(ex.GetType().Name + ": " + ex.Message);
            }
        }

        private ToolCallResult Execute(JsonElement arguments, AuditEntry entry)
        {
            if (arguments.ValueKind != JsonValueKind.Object)
            {
                throw new ToolException("this tool needs an arguments object with at least 'program'.");
            }

            string programId = ReadString(arguments, "program");

            if (programId == null)
            {
                throw new ToolException("'program' is required.");
            }

            entry.ProgramId = programId;
            ProgramEntry program = catalog.RequireForExecution(programId);
            entry.ExecutablePath = program.CanonicalPath;

            string workingDirectory = ResolveWorkingDirectory(arguments, program);
            entry.WorkingDirectory = workingDirectory;

            List<string> clientArguments = ReadArguments(arguments);

            if (clientArguments.Count > 0 && !program.AllowArgumentsFromClient)
            {
                throw new SandboxViolationException("'" + programId + "' does not accept arguments from the client.");
            }

            for (int i = 0; i < clientArguments.Count; i++)
            {
                ArgumentValidator.ValidateShape(clientArguments[i]);
                ArgumentValidator.ValidatePaths(guard, clientArguments[i], workingDirectory);
            }

            ExecutionRequest request = new ExecutionRequest();
            request.ProgramId = programId;
            request.ExecutablePath = program.CanonicalPath;
            request.WorkingDirectory = workingDirectory;

            for (int i = 0; i < program.FixedArguments.Count; i++)
            {
                request.Arguments.Add(program.FixedArguments[i]);
            }

            for (int i = 0; i < clientArguments.Count; i++)
            {
                request.Arguments.Add(clientArguments[i]);
            }

            ArgumentValidator.ValidateTotalLength(request.Arguments);
            request.TimeoutSeconds = ResolveTimeout(arguments, program);
            request.MaxOutputBytes = program.MaxOutputBytes > 0 ? program.MaxOutputBytes : config.MaxOutputBytes;

            for (int i = 0; i < request.Arguments.Count; i++)
            {
                entry.Arguments.Add(request.Arguments[i]);
            }

            ProcessRunResult result = runner.Run(request, program);

            entry.Outcome = "ok";
            entry.Reason = "";
            entry.ExitCode = result.ExitCode;
            entry.DurationMilliseconds = result.DurationMilliseconds;
            entry.TimedOut = result.TimedOut;
            entry.OutputTruncated = result.StandardOutputTruncated || result.StandardErrorTruncated;
            auditLog.Write(entry);

            return ToolCallResult.Success(FormatResult(request, result));
        }

        private string ResolveWorkingDirectory(JsonElement arguments, ProgramEntry program)
        {
            string raw = ReadString(arguments, "cwd");

            if (raw == null)
            {
                if (string.IsNullOrEmpty(program.DefaultWorkingDirectory))
                {
                    throw new ToolException("'cwd' is required because '" + program.Id
                                            + "' has no default working directory.");
                }

                return program.DefaultWorkingDirectory;
            }

            ResolvedPath resolved = guard.Require(raw, null, FolderPermission.Read);

            if (!Directory.Exists(resolved.FullPath))
            {
                throw new ToolException("the working directory does not exist: " + resolved.FullPath);
            }

            return resolved.FullPath;
        }

        private int ResolveTimeout(JsonElement arguments, ProgramEntry program)
        {
            int timeout = program.TimeoutSeconds > 0 ? program.TimeoutSeconds : config.DefaultTimeoutSeconds;
            JsonElement element;

            if (arguments.TryGetProperty("timeoutSeconds", out element) && element.ValueKind == JsonValueKind.Number)
            {
                int requested = element.GetInt32();

                if (requested <= 0)
                {
                    throw new ToolException("'timeoutSeconds' must be greater than zero.");
                }

                timeout = requested;
            }

            if (timeout > config.MaxTimeoutSeconds)
            {
                timeout = config.MaxTimeoutSeconds;
            }

            return timeout;
        }

        private static List<string> ReadArguments(JsonElement arguments)
        {
            List<string> values = new List<string>();
            JsonElement element;

            if (!arguments.TryGetProperty("args", out element))
            {
                return values;
            }

            if (element.ValueKind == JsonValueKind.Null)
            {
                return values;
            }

            if (element.ValueKind != JsonValueKind.Array)
            {
                throw new ToolException("'args' must be an array of strings.");
            }

            foreach (JsonElement item in element.EnumerateArray())
            {
                if (item.ValueKind != JsonValueKind.String)
                {
                    throw new ToolException("'args' must contain only strings.");
                }

                values.Add(item.GetString());
            }

            return values;
        }

        private static string ReadString(JsonElement arguments, string name)
        {
            JsonElement element;

            if (!arguments.TryGetProperty(name, out element) || element.ValueKind != JsonValueKind.String)
            {
                return null;
            }

            return element.GetString();
        }

        private static string FormatResult(ExecutionRequest request, ProcessRunResult result)
        {
            StringBuilder builder = new StringBuilder();
            builder.Append("program: ").Append(request.ProgramId).Append('\n');
            builder.Append("image: ").Append(request.ExecutablePath).Append('\n');
            builder.Append("cwd: ").Append(request.WorkingDirectory).Append('\n');
            builder.Append("argv:");

            for (int i = 0; i < request.Arguments.Count; i++)
            {
                builder.Append(' ').Append(JsonSerializer.Serialize(request.Arguments[i]));
            }

            builder.Append('\n');
            builder.Append("exitCode: ").Append(result.ExitCode.ToString(CultureInfo.InvariantCulture)).Append('\n');
            builder.Append("durationMs: ");
            builder.Append(result.DurationMilliseconds.ToString(CultureInfo.InvariantCulture)).Append('\n');
            builder.Append("timedOut: ").Append(result.TimedOut ? "true" : "false").Append('\n');
            builder.Append("\n--- stdout");

            if (result.StandardOutputTruncated)
            {
                builder.Append(" (truncated)");
            }

            builder.Append(" ---\n");
            builder.Append(result.StandardOutput);
            builder.Append("\n--- stderr");

            if (result.StandardErrorTruncated)
            {
                builder.Append(" (truncated)");
            }

            builder.Append(" ---\n");
            builder.Append(result.StandardError);
            return builder.ToString();
        }
    }
}

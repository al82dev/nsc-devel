using System.Collections.Generic;
using System.Text;
using System.Text.Json;
using NsExecMcp.Mcp;
using NsExecMcp.Sandbox;

namespace NsExecMcp.Tools
{
    // Reports the effective policy so the client knows what is allowed before trying.
    public class GetPolicyTool : IToolHandler
    {
        private const string Schema = "{\"type\":\"object\",\"properties\":{},\"additionalProperties\":false}";

        private readonly SandboxConfig config;
        private readonly PathGuard guard;
        private readonly string auditLogPath;
        private readonly ToolDefinition definition;

        public GetPolicyTool(SandboxConfig config, PathGuard guard, string auditLogPath)
        {
            this.config = config;
            this.guard = guard;
            this.auditLogPath = auditLogPath;
            definition = new ToolDefinition("get_policy", "Show the sandbox policy",
                                            "Shows the authorized folders with their permissions, the "
                                            + "execution limits and where the audit log is written.", Schema);
        }

        public ToolDefinition Definition
        {
            get { return definition; }
        }

        public ToolCallResult Invoke(JsonElement arguments, string callId)
        {
            StringBuilder builder = new StringBuilder();
            builder.Append("configuration: ").Append(config.SourceFile).Append('\n');
            builder.Append("auditLog: ").Append(auditLogPath).Append('\n');
            builder.Append("defaultTimeoutSeconds: ").Append(config.DefaultTimeoutSeconds).Append('\n');
            builder.Append("maxTimeoutSeconds: ").Append(config.MaxTimeoutSeconds).Append('\n');
            builder.Append("maxOutputBytes: ").Append(config.MaxOutputBytes).Append('\n');
            builder.Append("allowHardLinkedFiles: ");
            builder.Append(config.AllowHardLinkedFiles ? "true" : "false").Append('\n');
            builder.Append("\nauthorized folders (r=read, w=write, x=execute image):\n");

            List<string> roots = guard.DescribeRoots();

            for (int i = 0; i < roots.Count; i++)
            {
                builder.Append("  ").Append(roots[i]).Append('\n');
            }

            builder.Append("\nprograms: ");

            for (int i = 0; i < config.Programs.Count; i++)
            {
                if (i > 0)
                {
                    builder.Append(", ");
                }

                builder.Append(config.Programs[i].Id);
            }

            builder.Append('\n');
            return ToolCallResult.Success(builder.ToString());
        }
    }
}

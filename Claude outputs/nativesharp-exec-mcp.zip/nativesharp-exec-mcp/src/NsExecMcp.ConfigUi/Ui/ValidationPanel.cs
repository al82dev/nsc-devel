using System;
using System.Windows.Forms;

namespace NsExecMcp.ConfigUi.Ui
{
    // Shows the output of the server diagnostic modes.
    public class ValidationPanel : UserControl
    {
        private readonly TextBox output;

        public ValidationPanel()
        {
            Dock = DockStyle.Fill;
            Theme.ApplyContainer(this);

            output = new TextBox();
            output.Multiline = true;
            output.ReadOnly = true;
            output.WordWrap = false;
            output.ScrollBars = ScrollBars.Both;
            output.BackColor = Theme.Surface;
            output.ForeColor = Theme.Text;
            output.BorderStyle = BorderStyle.FixedSingle;
            output.Font = Theme.CreateMonospaceFont();
            output.Dock = DockStyle.Fill;
            Controls.Add(output);
        }

        public void SetText(string text)
        {
            string normalized = text == null ? "" : text.Replace("\r\n", "\n").Replace("\n", Environment.NewLine);
            output.Text = normalized;
            output.SelectionStart = 0;
            output.ScrollToCaret();
        }

        public void Clear()
        {
            output.Text = "";
        }
    }
}

using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using NsExecMcp.ConfigUi.Io;
using NsExecMcp.ConfigUi.Model;

namespace NsExecMcp.ConfigUi.Ui
{
    // Main window: three editing tabs on top, the validation output below.
    public class MainForm : Form
    {
        private readonly RootsPanel rootsPanel;
        private readonly ProgramsPanel programsPanel;
        private readonly GeneralPanel generalPanel;
        private readonly ValidationPanel validationPanel;
        private readonly StatusStrip statusStrip;
        private readonly ToolStripStatusLabel statusLabel;
        private readonly SplitContainer splitContainer;
        private ConfigDocument document;
        private UiSettings settings;
        private ServerRunner runner;

        public MainForm()
        {
            Text = "nsexec-mcp policy editor";
            ClientSize = new Size(1000, 760);
            StartPosition = FormStartPosition.CenterScreen;
            Theme.ApplyForm(this);

            settings = UiSettingsStore.Load();
            runner = new ServerRunner(settings.ServerExecutablePath);

            rootsPanel = new RootsPanel();
            programsPanel = new ProgramsPanel();
            generalPanel = new GeneralPanel();
            validationPanel = new ValidationPanel();

            rootsPanel.Changed += OnDocumentChanged;
            programsPanel.Changed += OnDocumentChanged;
            generalPanel.Changed += OnDocumentChanged;
            generalPanel.ServerExecutableChanged += OnServerExecutableChanged;
            programsPanel.Runner = runner;

            TabControl tabs = new TabControl();
            tabs.Dock = DockStyle.Fill;

            TabPage foldersPage = new TabPage("Folders");
            foldersPage.BackColor = Theme.Background;
            foldersPage.Controls.Add(rootsPanel);
            tabs.TabPages.Add(foldersPage);

            TabPage programsPage = new TabPage("Programs");
            programsPage.BackColor = Theme.Background;
            programsPage.Controls.Add(programsPanel);
            tabs.TabPages.Add(programsPage);

            TabPage generalPage = new TabPage("General");
            generalPage.BackColor = Theme.Background;
            generalPage.Controls.Add(generalPanel);
            tabs.TabPages.Add(generalPage);

            SplitContainer split = new SplitContainer();
            splitContainer = split;
            split.Dock = DockStyle.Fill;
            split.Orientation = Orientation.Horizontal;
            split.BackColor = Theme.Background;
            split.Panel1.BackColor = Theme.Background;
            split.Panel2.BackColor = Theme.Background;
            split.Panel1.Controls.Add(tabs);
            split.Panel2.Controls.Add(validationPanel);
            split.Panel2.Controls.Add(BuildActionBar());
            split.Panel1MinSize = 240;
            split.Panel2MinSize = 140;

            statusStrip = new StatusStrip();
            statusStrip.BackColor = Theme.ButtonFace;
            statusStrip.ForeColor = Theme.Text;
            statusLabel = new ToolStripStatusLabel("");
            statusLabel.ForeColor = Theme.Text;
            statusStrip.Items.Add(statusLabel);

            Controls.Add(split);
            Controls.Add(statusStrip);
            MainMenuStrip = BuildMenu();
            Controls.Add(MainMenuStrip);

            FormClosing += OnFormClosing;
            Shown += OnShown;

            NewDocument();
        }

        private MenuStrip BuildMenu()
        {
            MenuStrip menu = new MenuStrip();
            menu.BackColor = Theme.ButtonFace;
            menu.ForeColor = Theme.Text;

            ToolStripMenuItem file = new ToolStripMenuItem("File");
            file.DropDownItems.Add(CreateMenuItem("New", OnNew));
            file.DropDownItems.Add(CreateMenuItem("Open...", OnOpen));
            file.DropDownItems.Add(CreateMenuItem("Save", OnSave));
            file.DropDownItems.Add(CreateMenuItem("Save as...", OnSaveAs));
            file.DropDownItems.Add(new ToolStripSeparator());
            file.DropDownItems.Add(CreateMenuItem("Exit", OnExit));
            menu.Items.Add(file);

            ToolStripMenuItem tools = new ToolStripMenuItem("Tools");
            tools.DropDownItems.Add(CreateMenuItem("Validate policy", OnValidate));
            tools.DropDownItems.Add(CreateMenuItem("Probe a path...", OnProbe));
            tools.DropDownItems.Add(CreateMenuItem("List programs", OnListPrograms));
            tools.DropDownItems.Add(new ToolStripSeparator());
            tools.DropDownItems.Add(CreateMenuItem("Show MCP server entry...", OnShowSnippet));
            menu.Items.Add(tools);

            ToolStripMenuItem help = new ToolStripMenuItem("Help");
            help.DropDownItems.Add(CreateMenuItem("About", OnAbout));
            menu.Items.Add(help);

            return menu;
        }

        private static ToolStripMenuItem CreateMenuItem(string text, EventHandler handler)
        {
            ToolStripMenuItem item = new ToolStripMenuItem(text);
            item.ForeColor = Theme.Text;
            item.Click += handler;
            return item;
        }

        private FlowLayoutPanel BuildActionBar()
        {
            FlowLayoutPanel bar = new FlowLayoutPanel();
            bar.Dock = DockStyle.Top;
            bar.AutoSize = true;
            bar.BackColor = Theme.Background;

            Button validate = Theme.CreateButton("Validate policy");
            validate.Click += OnValidate;
            bar.Controls.Add(validate);

            Button probe = Theme.CreateButton("Probe a path...");
            probe.Click += OnProbe;
            bar.Controls.Add(probe);

            Button listPrograms = Theme.CreateButton("List programs");
            listPrograms.Click += OnListPrograms;
            bar.Controls.Add(listPrograms);

            Button clear = Theme.CreateButton("Clear output");
            clear.Click += OnClearOutput;
            bar.Controls.Add(clear);

            return bar;
        }

        private void OnShown(object sender, EventArgs args)
        {
            ApplySplitterPosition();

            if (!string.IsNullOrWhiteSpace(settings.LastConfigPath) && File.Exists(settings.LastConfigPath))
            {
                LoadDocument(settings.LastConfigPath);
            }
        }

        // Setting it here rather than in the constructor, where the control has no size yet.
        private void ApplySplitterPosition()
        {
            try
            {
                if (splitContainer.Height > 400)
                {
                    splitContainer.SplitterDistance = splitContainer.Height - 220;
                }
            }
            catch (Exception)
            {
                // The default position is good enough.
            }
        }

        private void NewDocument()
        {
            document = new ConfigDocument();
            BindAll();
            UpdateStatus();
        }

        private void LoadDocument(string path)
        {
            try
            {
                document = ConfigJsonReader.Read(path);
                BindAll();
                settings.LastConfigPath = path;
                UiSettingsStore.Save(settings);
                UpdateStatus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Open", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void BindAll()
        {
            rootsPanel.Bind(document);
            programsPanel.Bind(document);
            generalPanel.Bind(document);
            generalPanel.ServerExecutablePath = settings.ServerExecutablePath;
        }

        private void OnDocumentChanged(object sender, EventArgs args)
        {
            UpdateStatus();
        }

        private void OnServerExecutableChanged(object sender, EventArgs args)
        {
            settings.ServerExecutablePath = generalPanel.ServerExecutablePath;
            UiSettingsStore.Save(settings);
            runner = new ServerRunner(settings.ServerExecutablePath);
            programsPanel.Runner = runner;
            UpdateStatus();
        }

        private void UpdateStatus()
        {
            string file = document.FilePath == null ? "(not saved yet)" : document.FilePath;
            string modified = document.Modified ? "  *modified" : "";
            string server = runner.IsAvailable ? "" : "   server executable not set";
            statusLabel.Text = file + modified + server;
        }

        private void OnNew(object sender, EventArgs args)
        {
            if (!ConfirmDiscard())
            {
                return;
            }

            NewDocument();
        }

        private void OnOpen(object sender, EventArgs args)
        {
            if (!ConfirmDiscard())
            {
                return;
            }

            string picked = PathPickers.PickConfigToOpen(document.FilePath);

            if (picked == null)
            {
                return;
            }

            LoadDocument(picked);
        }

        private void OnSave(object sender, EventArgs args)
        {
            Save();
        }

        private void OnSaveAs(object sender, EventArgs args)
        {
            SaveAs();
        }

        private bool Save()
        {
            if (string.IsNullOrEmpty(document.FilePath))
            {
                return SaveAs();
            }

            return WriteTo(document.FilePath);
        }

        private bool SaveAs()
        {
            string picked = PathPickers.PickConfigToSave(document.FilePath);

            if (picked == null)
            {
                return false;
            }

            return WriteTo(picked);
        }

        private bool WriteTo(string path)
        {
            try
            {
                ConfigJsonWriter.Write(document, path);
                document.FilePath = path;
                document.Modified = false;
                settings.LastConfigPath = path;
                UiSettingsStore.Save(settings);
                UpdateStatus();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Save", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
        }

        // Validation always runs against a file on disk. When there are unsaved changes a draft is
        // written to the temp folder, so what is validated is what is on screen.
        private string GetFileToValidate(out bool isDraft)
        {
            isDraft = false;

            if (!document.Modified && !string.IsNullOrEmpty(document.FilePath))
            {
                return document.FilePath;
            }

            string folder = Path.Combine(Path.GetTempPath(), "nsexec-mcp");

            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }

            string draft = Path.Combine(folder, "draft-policy.json");
            ConfigJsonWriter.Write(document, draft);
            isDraft = true;
            return draft;
        }

        private void OnValidate(object sender, EventArgs args)
        {
            RunDiagnostic("check", null);
        }

        private void OnProbe(object sender, EventArgs args)
        {
            string path = TextPromptDialog.Ask(this, "Probe a path",
                                               "Path to canonicalize and check against the policy:", "");

            if (path == null)
            {
                return;
            }

            RunDiagnostic("probe", path);
        }

        private void OnListPrograms(object sender, EventArgs args)
        {
            RunDiagnostic("list", null);
        }

        private void RunDiagnostic(string mode, string argument)
        {
            if (!runner.IsAvailable)
            {
                validationPanel.SetText("The server executable is not set. Set it in the General tab.");
                return;
            }

            try
            {
                bool isDraft;
                string file = GetFileToValidate(out isDraft);
                ServerRunResult result;

                if (mode == "probe")
                {
                    result = runner.Probe(file, argument);
                }
                else if (mode == "list")
                {
                    result = runner.CallTool(file, "list_programs", null);
                }
                else
                {
                    result = runner.Check(file);
                }

                string header = "policy file: " + file + Environment.NewLine;

                if (isDraft)
                {
                    header += "draft with the unsaved changes on screen" + Environment.NewLine;
                }

                header += "exit code: " + result.ExitCode + Environment.NewLine
                          + "----------------------------------------" + Environment.NewLine;
                validationPanel.SetText(header + result.Output);
            }
            catch (Exception ex)
            {
                validationPanel.SetText(ex.Message);
            }
        }

        private void OnClearOutput(object sender, EventArgs args)
        {
            validationPanel.Clear();
        }

        private void OnShowSnippet(object sender, EventArgs args)
        {
            using (SnippetDialog dialog = new SnippetDialog(settings.ServerExecutablePath, document.FilePath))
            {
                dialog.ShowDialog(this);
            }
        }

        private void OnAbout(object sender, EventArgs args)
        {
            MessageBox.Show(this,
                            "nsexec-mcp policy editor" + Environment.NewLine
                            + "Edits the folders, whitelisted programs and limits of the MCP server."
                            + Environment.NewLine + Environment.NewLine
                            + "Validation is delegated to nsexec-mcp.exe --check, so the editor and the "
                            + "server can never disagree about the rules.",
                            "About", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void OnExit(object sender, EventArgs args)
        {
            Close();
        }

        private bool ConfirmDiscard()
        {
            if (!document.Modified)
            {
                return true;
            }

            DialogResult answer = MessageBox.Show(this, "There are unsaved changes. Save them now?",
                                                  "Policy editor", MessageBoxButtons.YesNoCancel,
                                                  MessageBoxIcon.Question);

            if (answer == DialogResult.Cancel)
            {
                return false;
            }

            if (answer == DialogResult.Yes)
            {
                return Save();
            }

            return true;
        }

        private void OnFormClosing(object sender, FormClosingEventArgs args)
        {
            if (!ConfirmDiscard())
            {
                args.Cancel = true;
            }
        }
    }
}

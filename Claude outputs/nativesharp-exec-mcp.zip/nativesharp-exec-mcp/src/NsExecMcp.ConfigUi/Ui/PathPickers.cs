using System;
using System.IO;
using System.Windows.Forms;

namespace NsExecMcp.ConfigUi.Ui
{
    // Small wrappers over the common dialogs, all returning null when the user cancels.
    public static class PathPickers
    {
        public static string PickFolder(string title, string current)
        {
            using (FolderBrowserDialog dialog = new FolderBrowserDialog())
            {
                dialog.Description = title;
                dialog.UseDescriptionForTitle = true;
                dialog.ShowNewFolderButton = true;

                if (!string.IsNullOrWhiteSpace(current) && Directory.Exists(current))
                {
                    dialog.SelectedPath = current;
                }

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    return dialog.SelectedPath;
                }
            }

            return null;
        }

        public static string PickExecutable(string title, string current)
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = title;
                dialog.Filter = "Executables (*.exe)|*.exe|All files (*.*)|*.*";
                dialog.CheckFileExists = true;

                if (!string.IsNullOrWhiteSpace(current))
                {
                    string folder = Path.GetDirectoryName(current);

                    if (!string.IsNullOrEmpty(folder) && Directory.Exists(folder))
                    {
                        dialog.InitialDirectory = folder;
                    }
                }

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    return dialog.FileName;
                }
            }

            return null;
        }

        public static string PickConfigToOpen(string current)
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = "Open a policy file";
                dialog.Filter = "Policy files (*.json)|*.json|All files (*.*)|*.*";
                dialog.CheckFileExists = true;
                ApplyInitialDirectory(dialog, current);

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    return dialog.FileName;
                }
            }

            return null;
        }

        public static string PickConfigToSave(string current)
        {
            using (SaveFileDialog dialog = new SaveFileDialog())
            {
                dialog.Title = "Save the policy file";
                dialog.Filter = "Policy files (*.json)|*.json|All files (*.*)|*.*";
                dialog.DefaultExt = "json";
                dialog.FileName = "nsexec-mcp.config.json";

                if (!string.IsNullOrWhiteSpace(current))
                {
                    dialog.FileName = Path.GetFileName(current);
                    string folder = Path.GetDirectoryName(current);

                    if (!string.IsNullOrEmpty(folder) && Directory.Exists(folder))
                    {
                        dialog.InitialDirectory = folder;
                    }
                }

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    return dialog.FileName;
                }
            }

            return null;
        }

        public static string PickFileToWrite(string title, string current)
        {
            using (SaveFileDialog dialog = new SaveFileDialog())
            {
                dialog.Title = title;
                dialog.Filter = "All files (*.*)|*.*";
                dialog.OverwritePrompt = false;
                dialog.CheckPathExists = false;

                if (!string.IsNullOrWhiteSpace(current))
                {
                    dialog.FileName = Path.GetFileName(current);
                    string folder = Path.GetDirectoryName(current);

                    if (!string.IsNullOrEmpty(folder) && Directory.Exists(folder))
                    {
                        dialog.InitialDirectory = folder;
                    }
                }

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    return dialog.FileName;
                }
            }

            return null;
        }

        private static void ApplyInitialDirectory(FileDialog dialog, string current)
        {
            if (string.IsNullOrWhiteSpace(current))
            {
                return;
            }

            string folder = Path.GetDirectoryName(current);

            if (!string.IsNullOrEmpty(folder) && Directory.Exists(folder))
            {
                dialog.InitialDirectory = folder;
            }
        }
    }
}

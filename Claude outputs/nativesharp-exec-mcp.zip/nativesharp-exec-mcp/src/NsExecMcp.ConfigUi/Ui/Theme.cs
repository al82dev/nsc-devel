using System.Drawing;
using System.Windows.Forms;

namespace NsExecMcp.ConfigUi.Ui
{
    // Light theme used everywhere. Colors are set explicitly so the window never follows a dark
    // system theme.
    public static class Theme
    {
        public static readonly Color Background = Color.FromArgb(246, 246, 246);
        public static readonly Color Surface = Color.White;
        public static readonly Color Text = Color.FromArgb(32, 32, 32);
        public static readonly Color MutedText = Color.FromArgb(100, 100, 100);
        public static readonly Color Border = Color.FromArgb(202, 202, 202);
        public static readonly Color ButtonFace = Color.FromArgb(238, 238, 238);

        public static Font CreateUiFont()
        {
            return new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
        }

        public static Font CreateMonospaceFont()
        {
            return new Font("Consolas", 9F, FontStyle.Regular, GraphicsUnit.Point);
        }

        public static void ApplyForm(Form form)
        {
            form.BackColor = Background;
            form.ForeColor = Text;
            form.Font = CreateUiFont();
        }

        public static void ApplyContainer(Control control)
        {
            control.BackColor = Background;
            control.ForeColor = Text;
        }

        public static Label CreateLabel(string text)
        {
            Label label = new Label();
            label.Text = text;
            label.AutoSize = true;
            label.ForeColor = Text;
            label.BackColor = Color.Transparent;
            label.Margin = new Padding(3, 7, 3, 3);
            return label;
        }

        public static Label CreateHint(string text)
        {
            Label label = CreateLabel(text);
            label.ForeColor = MutedText;
            return label;
        }

        public static TextBox CreateTextBox()
        {
            TextBox box = new TextBox();
            box.BackColor = Surface;
            box.ForeColor = Text;
            box.BorderStyle = BorderStyle.FixedSingle;
            box.Dock = DockStyle.Fill;
            box.Margin = new Padding(3, 3, 3, 3);
            return box;
        }

        public static Button CreateButton(string text)
        {
            Button button = new Button();
            button.Text = text;
            button.BackColor = ButtonFace;
            button.ForeColor = Text;
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderColor = Border;
            button.AutoSize = true;
            button.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            button.Padding = new Padding(8, 2, 8, 2);
            button.Margin = new Padding(3, 3, 3, 3);
            return button;
        }

        public static CheckBox CreateCheckBox(string text)
        {
            CheckBox box = new CheckBox();
            box.Text = text;
            box.AutoSize = true;
            box.ForeColor = Text;
            box.BackColor = Color.Transparent;
            box.Margin = new Padding(3, 5, 3, 3);
            return box;
        }

        public static NumericUpDown CreateNumeric(int minimum, int maximum)
        {
            NumericUpDown numeric = new NumericUpDown();
            numeric.Minimum = minimum;
            numeric.Maximum = maximum;
            numeric.BackColor = Surface;
            numeric.ForeColor = Text;
            numeric.BorderStyle = BorderStyle.FixedSingle;
            numeric.Width = 140;
            numeric.Margin = new Padding(3, 3, 3, 3);
            return numeric;
        }

        public static ListView CreateListView()
        {
            ListView list = new ListView();
            list.View = View.Details;
            list.FullRowSelect = true;
            list.MultiSelect = false;
            list.HideSelection = false;
            list.BackColor = Surface;
            list.ForeColor = Text;
            list.BorderStyle = BorderStyle.FixedSingle;
            list.Dock = DockStyle.Fill;
            return list;
        }

        public static ListBox CreateListBox()
        {
            ListBox list = new ListBox();
            list.BackColor = Surface;
            list.ForeColor = Text;
            list.BorderStyle = BorderStyle.FixedSingle;
            list.Dock = DockStyle.Fill;
            return list;
        }

        public static DataGridView CreateGrid()
        {
            DataGridView grid = new DataGridView();
            grid.BackgroundColor = Surface;
            grid.ForeColor = Text;
            grid.GridColor = Border;
            grid.BorderStyle = BorderStyle.FixedSingle;
            grid.EnableHeadersVisualStyles = false;
            grid.ColumnHeadersDefaultCellStyle.BackColor = ButtonFace;
            grid.ColumnHeadersDefaultCellStyle.ForeColor = Text;
            grid.DefaultCellStyle.BackColor = Surface;
            grid.DefaultCellStyle.ForeColor = Text;
            grid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(205, 224, 242);
            grid.DefaultCellStyle.SelectionForeColor = Text;
            grid.RowHeadersVisible = false;
            grid.AllowUserToResizeRows = false;
            grid.Dock = DockStyle.Fill;
            return grid;
        }

        public static GroupBox CreateGroup(string text)
        {
            GroupBox group = new GroupBox();
            group.Text = text;
            group.ForeColor = Text;
            group.BackColor = Background;
            group.Padding = new Padding(8, 6, 8, 8);
            return group;
        }

        public static TableLayoutPanel CreateFormLayout(int columns)
        {
            TableLayoutPanel layout = new TableLayoutPanel();
            layout.ColumnCount = columns;
            layout.Dock = DockStyle.Fill;
            layout.BackColor = Background;
            layout.ForeColor = Text;
            layout.AutoSize = false;
            layout.Padding = new Padding(4);
            return layout;
        }
    }
}

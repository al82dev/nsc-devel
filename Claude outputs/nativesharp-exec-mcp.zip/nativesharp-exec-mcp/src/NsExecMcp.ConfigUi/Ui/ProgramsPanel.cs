using System;
using System.Text;
using System.Windows.Forms;
using NsExecMcp.ConfigUi.Io;
using NsExecMcp.ConfigUi.Model;

namespace NsExecMcp.ConfigUi.Ui
{
    // Editor of the whitelisted programs.
    public class ProgramsPanel : UserControl
    {
        private readonly ListView list;
        private TextBox idBox;
        private TextBox pathBox;
        private TextBox descriptionBox;
        private TextBox workingDirectoryBox;
        private TextBox fixedArgumentsBox;
        private TextBox sha256Box;
        private CheckBox allowArgumentsBox;
        private CheckBox acknowledgeInterpreterBox;
        private NumericUpDown timeoutBox;
        private NumericUpDown maxOutputBox;
        private DataGridView environmentGrid;
        private ConfigDocument document;
        private bool loading;

        public ProgramsPanel()
        {
            Dock = DockStyle.Fill;
            Theme.ApplyContainer(this);

            TableLayoutPanel layout = Theme.CreateFormLayout(1);
            layout.RowCount = 3;
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 32F));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 68F));

            list = Theme.CreateListView();
            list.Columns.Add("Id", 140);
            list.Columns.Add("Executable", 520);
            list.SelectedIndexChanged += OnSelectionChanged;
            layout.Controls.Add(list, 0, 0);

            FlowLayoutPanel buttons = new FlowLayoutPanel();
            buttons.AutoSize = true;
            buttons.Dock = DockStyle.Fill;
            buttons.BackColor = Theme.Background;

            Button addButton = Theme.CreateButton("Add program...");
            addButton.Click += OnAdd;
            buttons.Controls.Add(addButton);

            Button removeButton = Theme.CreateButton("Remove");
            removeButton.Click += OnRemove;
            buttons.Controls.Add(removeButton);

            layout.Controls.Add(buttons, 0, 1);
            layout.Controls.Add(BuildEditor(), 0, 2);
            Controls.Add(layout);
            SetEditorEnabled(false);
        }

        public event EventHandler Changed;

        // Used by the SHA-256 button; may be null until the server executable is known.
        public ServerRunner Runner { get; set; }

        private GroupBox BuildEditor()
        {
            GroupBox group = Theme.CreateGroup("Selected program");
            group.Dock = DockStyle.Fill;

            Panel scroll = new Panel();
            scroll.Dock = DockStyle.Fill;
            scroll.AutoScroll = true;
            scroll.BackColor = Theme.Background;

            TableLayoutPanel layout = Theme.CreateFormLayout(3);
            layout.Dock = DockStyle.Top;
            layout.AutoSize = true;
            layout.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));

            int row = 0;

            layout.Controls.Add(Theme.CreateLabel("Id"), 0, row);
            idBox = Theme.CreateTextBox();
            idBox.TextChanged += OnFieldChanged;
            layout.Controls.Add(idBox, 1, row);
            layout.Controls.Add(Theme.CreateHint("name used by the client"), 2, row);
            row++;

            layout.Controls.Add(Theme.CreateLabel("Executable"), 0, row);
            pathBox = Theme.CreateTextBox();
            pathBox.TextChanged += OnFieldChanged;
            layout.Controls.Add(pathBox, 1, row);
            Button browseExecutable = Theme.CreateButton("Browse...");
            browseExecutable.Click += OnBrowseExecutable;
            layout.Controls.Add(browseExecutable, 2, row);
            row++;

            layout.Controls.Add(Theme.CreateLabel("Description"), 0, row);
            descriptionBox = Theme.CreateTextBox();
            descriptionBox.TextChanged += OnFieldChanged;
            layout.Controls.Add(descriptionBox, 1, row);
            row++;

            layout.Controls.Add(Theme.CreateLabel("Default working folder"), 0, row);
            workingDirectoryBox = Theme.CreateTextBox();
            workingDirectoryBox.TextChanged += OnFieldChanged;
            layout.Controls.Add(workingDirectoryBox, 1, row);
            Button browseWorkingDirectory = Theme.CreateButton("Browse...");
            browseWorkingDirectory.Click += OnBrowseWorkingDirectory;
            layout.Controls.Add(browseWorkingDirectory, 2, row);
            row++;

            layout.Controls.Add(Theme.CreateLabel("Fixed arguments"), 0, row);
            fixedArgumentsBox = Theme.CreateTextBox();
            fixedArgumentsBox.Multiline = true;
            fixedArgumentsBox.Dock = DockStyle.None;
            fixedArgumentsBox.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            fixedArgumentsBox.Height = 66;
            fixedArgumentsBox.ScrollBars = ScrollBars.Vertical;
            fixedArgumentsBox.Font = Theme.CreateMonospaceFont();
            fixedArgumentsBox.TextChanged += OnFieldChanged;
            layout.Controls.Add(fixedArgumentsBox, 1, row);
            layout.Controls.Add(Theme.CreateHint("one per line, always first"), 2, row);
            row++;

            allowArgumentsBox = Theme.CreateCheckBox("Accept arguments from the client");
            allowArgumentsBox.CheckedChanged += OnFieldChanged;
            layout.Controls.Add(allowArgumentsBox, 1, row);
            row++;

            acknowledgeInterpreterBox = Theme.CreateCheckBox(
                "This is a known interpreter and I accept it (needs fixed arguments and no client arguments)");
            acknowledgeInterpreterBox.CheckedChanged += OnFieldChanged;
            layout.Controls.Add(acknowledgeInterpreterBox, 1, row);
            row++;

            layout.Controls.Add(Theme.CreateLabel("Timeout (s)"), 0, row);
            timeoutBox = Theme.CreateNumeric(0, 86400);
            timeoutBox.ValueChanged += OnFieldChanged;
            layout.Controls.Add(timeoutBox, 1, row);
            layout.Controls.Add(Theme.CreateHint("0 uses the general value"), 2, row);
            row++;

            layout.Controls.Add(Theme.CreateLabel("Max output (bytes)"), 0, row);
            maxOutputBox = Theme.CreateNumeric(0, 104857600);
            maxOutputBox.Increment = 65536;
            maxOutputBox.ValueChanged += OnFieldChanged;
            layout.Controls.Add(maxOutputBox, 1, row);
            layout.Controls.Add(Theme.CreateHint("0 uses the general value"), 2, row);
            row++;

            layout.Controls.Add(Theme.CreateLabel("SHA-256"), 0, row);
            sha256Box = Theme.CreateTextBox();
            sha256Box.Font = Theme.CreateMonospaceFont();
            sha256Box.TextChanged += OnFieldChanged;
            layout.Controls.Add(sha256Box, 1, row);
            Button computeHash = Theme.CreateButton("Compute");
            computeHash.Click += OnComputeHash;
            layout.Controls.Add(computeHash, 2, row);
            row++;

            layout.Controls.Add(Theme.CreateLabel("Environment"), 0, row);
            environmentGrid = Theme.CreateGrid();
            environmentGrid.Dock = DockStyle.None;
            environmentGrid.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            environmentGrid.Height = 120;
            environmentGrid.Columns.Add("name", "Name");
            environmentGrid.Columns.Add("value", "Value");
            environmentGrid.Columns[0].Width = 180;
            environmentGrid.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            environmentGrid.CellEndEdit += OnEnvironmentCellEndEdit;
            environmentGrid.UserDeletedRow += OnEnvironmentRowDeleted;
            layout.Controls.Add(environmentGrid, 1, row);
            layout.Controls.Add(Theme.CreateHint("absolute paths must stay inside authorized folders"), 2, row);
            row++;

            layout.RowCount = row;
            scroll.Controls.Add(layout);
            group.Controls.Add(scroll);
            return group;
        }

        public void Bind(ConfigDocument value)
        {
            document = value;
            Reload();
        }

        private void Reload()
        {
            loading = true;
            list.Items.Clear();

            if (document != null)
            {
                for (int i = 0; i < document.Programs.Count; i++)
                {
                    list.Items.Add(BuildRow(document.Programs[i]));
                }
            }

            loading = false;
            LoadSelection();
        }

        private static ListViewItem BuildRow(ProgramItem entry)
        {
            ListViewItem row = new ListViewItem(entry.Id == null ? "" : entry.Id);
            row.SubItems.Add(entry.Path == null ? "" : entry.Path);
            row.Tag = entry;
            return row;
        }

        private ProgramItem GetSelected()
        {
            if (list.SelectedItems.Count == 0)
            {
                return null;
            }

            return list.SelectedItems[0].Tag as ProgramItem;
        }

        private void LoadSelection()
        {
            ProgramItem entry = GetSelected();
            loading = true;

            if (entry == null)
            {
                idBox.Text = "";
                pathBox.Text = "";
                descriptionBox.Text = "";
                workingDirectoryBox.Text = "";
                fixedArgumentsBox.Text = "";
                sha256Box.Text = "";
                allowArgumentsBox.Checked = true;
                acknowledgeInterpreterBox.Checked = false;
                timeoutBox.Value = 0;
                maxOutputBox.Value = 0;
                environmentGrid.Rows.Clear();
                SetEditorEnabled(false);
                loading = false;
                return;
            }

            idBox.Text = entry.Id == null ? "" : entry.Id;
            pathBox.Text = entry.Path == null ? "" : entry.Path;
            descriptionBox.Text = entry.Description == null ? "" : entry.Description;
            workingDirectoryBox.Text = entry.DefaultWorkingDirectory == null
                                       ? "" : entry.DefaultWorkingDirectory;
            fixedArgumentsBox.Text = JoinLines(entry);
            sha256Box.Text = entry.Sha256 == null ? "" : entry.Sha256;
            allowArgumentsBox.Checked = entry.AllowArgumentsFromClient;
            acknowledgeInterpreterBox.Checked = entry.AcknowledgeInterpreter;
            timeoutBox.Value = entry.TimeoutSeconds;
            maxOutputBox.Value = entry.MaxOutputBytes;

            environmentGrid.Rows.Clear();

            for (int i = 0; i < entry.Environment.Count; i++)
            {
                EnvironmentItem variable = entry.Environment[i];
                environmentGrid.Rows.Add(variable.Name, variable.Value);
            }

            SetEditorEnabled(true);
            loading = false;
        }

        private static string JoinLines(ProgramItem entry)
        {
            StringBuilder builder = new StringBuilder();

            for (int i = 0; i < entry.FixedArguments.Count; i++)
            {
                builder.AppendLine(entry.FixedArguments[i]);
            }

            return builder.ToString();
        }

        private void SetEditorEnabled(bool enabled)
        {
            idBox.Enabled = enabled;
            pathBox.Enabled = enabled;
            descriptionBox.Enabled = enabled;
            workingDirectoryBox.Enabled = enabled;
            fixedArgumentsBox.Enabled = enabled;
            sha256Box.Enabled = enabled;
            allowArgumentsBox.Enabled = enabled;
            acknowledgeInterpreterBox.Enabled = enabled;
            timeoutBox.Enabled = enabled;
            maxOutputBox.Enabled = enabled;
            environmentGrid.Enabled = enabled;
        }

        private void OnSelectionChanged(object sender, EventArgs args)
        {
            if (loading)
            {
                return;
            }

            LoadSelection();
        }

        private void OnFieldChanged(object sender, EventArgs args)
        {
            if (loading)
            {
                return;
            }

            ProgramItem entry = GetSelected();

            if (entry == null)
            {
                return;
            }

            entry.Id = idBox.Text.Trim();
            entry.Path = pathBox.Text;
            entry.Description = descriptionBox.Text;
            entry.DefaultWorkingDirectory = workingDirectoryBox.Text;
            entry.Sha256 = sha256Box.Text.Trim();
            entry.AllowArgumentsFromClient = allowArgumentsBox.Checked;
            entry.AcknowledgeInterpreter = acknowledgeInterpreterBox.Checked;
            entry.TimeoutSeconds = (int)timeoutBox.Value;
            entry.MaxOutputBytes = (int)maxOutputBox.Value;

            entry.FixedArguments.Clear();
            string[] lines = fixedArgumentsBox.Lines;

            for (int i = 0; i < lines.Length; i++)
            {
                if (lines[i].Length > 0)
                {
                    entry.FixedArguments.Add(lines[i]);
                }
            }

            ListViewItem row = list.SelectedItems[0];
            row.SubItems[0].Text = entry.Id;
            row.SubItems[1].Text = entry.Path;
            RaiseChanged();
        }

        private void OnEnvironmentCellEndEdit(object sender, DataGridViewCellEventArgs args)
        {
            OnEnvironmentChanged(sender, EventArgs.Empty);
        }

        private void OnEnvironmentRowDeleted(object sender, DataGridViewRowEventArgs args)
        {
            OnEnvironmentChanged(sender, EventArgs.Empty);
        }

        private void OnEnvironmentChanged(object sender, EventArgs args)
        {
            if (loading)
            {
                return;
            }

            ProgramItem entry = GetSelected();

            if (entry == null)
            {
                return;
            }

            entry.Environment.Clear();

            for (int i = 0; i < environmentGrid.Rows.Count; i++)
            {
                DataGridViewRow row = environmentGrid.Rows[i];

                if (row.IsNewRow)
                {
                    continue;
                }

                object name = row.Cells[0].Value;
                object value = row.Cells[1].Value;

                if (name == null || string.IsNullOrWhiteSpace(name.ToString()))
                {
                    continue;
                }

                entry.Environment.Add(new EnvironmentItem(name.ToString().Trim(),
                                                          value == null ? "" : value.ToString()));
            }

            RaiseChanged();
        }

        private void OnBrowseExecutable(object sender, EventArgs args)
        {
            ProgramItem entry = GetSelected();

            if (entry == null)
            {
                return;
            }

            string picked = PathPickers.PickExecutable("Choose the executable", entry.Path);

            if (picked == null)
            {
                return;
            }

            pathBox.Text = picked;
        }

        private void OnBrowseWorkingDirectory(object sender, EventArgs args)
        {
            ProgramItem entry = GetSelected();

            if (entry == null)
            {
                return;
            }

            string picked = PathPickers.PickFolder("Choose the default working folder",
                                                   entry.DefaultWorkingDirectory);

            if (picked == null)
            {
                return;
            }

            workingDirectoryBox.Text = picked;
        }

        private void OnComputeHash(object sender, EventArgs args)
        {
            ProgramItem entry = GetSelected();

            if (entry == null)
            {
                return;
            }

            if (Runner == null || !Runner.IsAvailable)
            {
                MessageBox.Show(this, "Set the server executable in the General tab first.",
                                "SHA-256", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (string.IsNullOrWhiteSpace(entry.Path))
            {
                return;
            }

            ServerRunResult result = Runner.Hash(entry.Path);

            if (!result.Succeeded)
            {
                MessageBox.Show(this, result.Output, "SHA-256", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string output = result.Output.Trim();
            int separator = output.IndexOf(' ');

            if (separator > 0)
            {
                output = output.Substring(0, separator);
            }

            sha256Box.Text = output;
        }

        private void OnAdd(object sender, EventArgs args)
        {
            if (document == null)
            {
                return;
            }

            string picked = PathPickers.PickExecutable("Choose the executable to whitelist", null);

            if (picked == null)
            {
                return;
            }

            ProgramItem entry = new ProgramItem();
            entry.Path = picked;
            entry.Id = System.IO.Path.GetFileNameWithoutExtension(picked).ToLowerInvariant();
            document.Programs.Add(entry);

            ListViewItem row = BuildRow(entry);
            list.Items.Add(row);
            row.Selected = true;
            list.Focus();
            RaiseChanged();
        }

        private void OnRemove(object sender, EventArgs args)
        {
            ProgramItem entry = GetSelected();

            if (entry == null || document == null)
            {
                return;
            }

            document.Programs.Remove(entry);
            list.Items.Remove(list.SelectedItems[0]);
            LoadSelection();
            RaiseChanged();
        }

        private void RaiseChanged()
        {
            if (document != null)
            {
                document.Modified = true;
            }

            if (Changed != null)
            {
                Changed(this, EventArgs.Empty);
            }
        }
    }
}

using System;
using System.Drawing;
using System.Windows.Forms;

namespace NsExecMcp.ConfigUi.Ui
{
    // Small modal dialog asking for one line of text.
    public class TextPromptDialog : Form
    {
        private readonly TextBox valueBox;

        public TextPromptDialog(string title, string prompt, string initialValue)
        {
            Text = title;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            StartPosition = FormStartPosition.CenterParent;
            MinimizeBox = false;
            MaximizeBox = false;
            ClientSize = new Size(520, 120);
            Theme.ApplyForm(this);

            Label label = Theme.CreateLabel(prompt);
            label.Location = new Point(12, 14);
            Controls.Add(label);

            valueBox = Theme.CreateTextBox();
            valueBox.Dock = DockStyle.None;
            valueBox.Location = new Point(12, 42);
            valueBox.Width = 496;
            valueBox.Text = initialValue == null ? "" : initialValue;
            Controls.Add(valueBox);

            Button acceptButton = Theme.CreateButton("OK");
            acceptButton.Location = new Point(332, 78);
            acceptButton.Width = 84;
            acceptButton.DialogResult = DialogResult.OK;
            Controls.Add(acceptButton);

            Button cancelButton = Theme.CreateButton("Cancel");
            cancelButton.Location = new Point(424, 78);
            cancelButton.Width = 84;
            cancelButton.DialogResult = DialogResult.Cancel;
            Controls.Add(cancelButton);

            AcceptButton = acceptButton;
            CancelButton = cancelButton;
        }

        public string Value
        {
            get { return valueBox.Text; }
        }

        // Returns the typed text, or null when the dialog was cancelled or left empty.
        public static string Ask(IWin32Window owner, string title, string prompt, string initialValue)
        {
            using (TextPromptDialog dialog = new TextPromptDialog(title, prompt, initialValue))
            {
                if (dialog.ShowDialog(owner) != DialogResult.OK)
                {
                    return null;
                }

                string value = dialog.Value;

                if (string.IsNullOrWhiteSpace(value))
                {
                    return null;
                }

                return value.Trim();
            }
        }
    }
}

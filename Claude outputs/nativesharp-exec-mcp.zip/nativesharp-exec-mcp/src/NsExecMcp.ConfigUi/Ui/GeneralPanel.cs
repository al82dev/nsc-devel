using System;
using System.Windows.Forms;
using NsExecMcp.ConfigUi.Model;

namespace NsExecMcp.ConfigUi.Ui
{
    // Editor of the limits, the audit log and the editor preferences.
    public class GeneralPanel : UserControl
    {
        private NumericUpDown defaultTimeoutBox;
        private NumericUpDown maxTimeoutBox;
        private NumericUpDown maxOutputBox;
        private CheckBox allowHardLinksBox;
        private TextBox auditLogBox;
        private TextBox tempDirectoryBox;
        private ListBox pathFoldersList;
        private TextBox serverExecutableBox;
        private ConfigDocument document;
        private bool loading;

        public GeneralPanel()
        {
            Dock = DockStyle.Fill;
            AutoScroll = true;
            Theme.ApplyContainer(this);
            Controls.Add(BuildLayout());
        }

        public event EventHandler Changed;

        public event EventHandler ServerExecutableChanged;

        public string ServerExecutablePath
        {
            get { return serverExecutableBox.Text.Trim(); }
            set
            {
                loading = true;
                serverExecutableBox.Text = value == null ? "" : value;
                loading = false;
            }
        }

        private TableLayoutPanel BuildLayout()
        {
            TableLayoutPanel layout = Theme.CreateFormLayout(3);
            layout.Dock = DockStyle.Top;
            layout.AutoSize = true;
            layout.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));

            int row = 0;

            layout.Controls.Add(Theme.CreateLabel("Default timeout (s)"), 0, row);
            defaultTimeoutBox = Theme.CreateNumeric(1, 86400);
            defaultTimeoutBox.ValueChanged += OnFieldChanged;
            layout.Controls.Add(defaultTimeoutBox, 1, row);
            row++;

            layout.Controls.Add(Theme.CreateLabel("Maximum timeout (s)"), 0, row);
            maxTimeoutBox = Theme.CreateNumeric(1, 86400);
            maxTimeoutBox.ValueChanged += OnFieldChanged;
            layout.Controls.Add(maxTimeoutBox, 1, row);
            layout.Controls.Add(Theme.CreateHint("ceiling a call can never exceed"), 2, row);
            row++;

            layout.Controls.Add(Theme.CreateLabel("Max output (bytes)"), 0, row);
            maxOutputBox = Theme.CreateNumeric(1024, 104857600);
            maxOutputBox.Increment = 65536;
            maxOutputBox.ValueChanged += OnFieldChanged;
            layout.Controls.Add(maxOutputBox, 1, row);
            layout.Controls.Add(Theme.CreateHint("per stream"), 2, row);
            row++;

            allowHardLinksBox = Theme.CreateCheckBox("Allow files that have more than one hard link");
            allowHardLinksBox.CheckedChanged += OnFieldChanged;
            layout.Controls.Add(allowHardLinksBox, 1, row);
            row++;

            layout.Controls.Add(Theme.CreateLabel("Audit log"), 0, row);
            auditLogBox = Theme.CreateTextBox();
            auditLogBox.TextChanged += OnFieldChanged;
            layout.Controls.Add(auditLogBox, 1, row);
            Button browseAudit = Theme.CreateButton("Browse...");
            browseAudit.Click += OnBrowseAuditLog;
            layout.Controls.Add(browseAudit, 2, row);
            row++;

            layout.Controls.Add(Theme.CreateHint(""), 0, row);
            layout.Controls.Add(Theme.CreateHint("keep it outside every writable folder"), 1, row);
            row++;

            layout.Controls.Add(Theme.CreateLabel("Temp folder"), 0, row);
            tempDirectoryBox = Theme.CreateTextBox();
            tempDirectoryBox.TextChanged += OnFieldChanged;
            layout.Controls.Add(tempDirectoryBox, 1, row);
            Button browseTemp = Theme.CreateButton("Browse...");
            browseTemp.Click += OnBrowseTempDirectory;
            layout.Controls.Add(browseTemp, 2, row);
            row++;

            layout.Controls.Add(Theme.CreateLabel("Extra PATH folders"), 0, row);
            pathFoldersList = Theme.CreateListBox();
            pathFoldersList.Dock = DockStyle.None;
            pathFoldersList.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            pathFoldersList.Height = 90;
            layout.Controls.Add(pathFoldersList, 1, row);

            FlowLayoutPanel pathButtons = new FlowLayoutPanel();
            pathButtons.AutoSize = true;
            pathButtons.FlowDirection = FlowDirection.TopDown;
            pathButtons.BackColor = Theme.Background;

            Button addFolder = Theme.CreateButton("Add...");
            addFolder.Click += OnAddPathFolder;
            pathButtons.Controls.Add(addFolder);

            Button removeFolder = Theme.CreateButton("Remove");
            removeFolder.Click += OnRemovePathFolder;
            pathButtons.Controls.Add(removeFolder);

            layout.Controls.Add(pathButtons, 2, row);
            row++;

            layout.Controls.Add(Theme.CreateLabel("Server executable"), 0, row);
            serverExecutableBox = Theme.CreateTextBox();
            serverExecutableBox.TextChanged += OnServerExecutableChanged;
            layout.Controls.Add(serverExecutableBox, 1, row);
            Button browseServer = Theme.CreateButton("Browse...");
            browseServer.Click += OnBrowseServer;
            layout.Controls.Add(browseServer, 2, row);
            row++;

            layout.Controls.Add(Theme.CreateHint(""), 0, row);
            layout.Controls.Add(Theme.CreateHint("editor setting, not written to the policy file; "
                                                 + "used to validate and to compute hashes"), 1, row);
            row++;

            layout.RowCount = row;
            return layout;
        }

        public void Bind(ConfigDocument value)
        {
            document = value;
            loading = true;

            defaultTimeoutBox.Value = Clamp(document.DefaultTimeoutSeconds, 1, 86400);
            maxTimeoutBox.Value = Clamp(document.MaxTimeoutSeconds, 1, 86400);
            maxOutputBox.Value = Clamp(document.MaxOutputBytes, 1024, 104857600);
            allowHardLinksBox.Checked = document.AllowHardLinkedFiles;
            auditLogBox.Text = document.AuditLogPath == null ? "" : document.AuditLogPath;
            tempDirectoryBox.Text = document.TempDirectory == null ? "" : document.TempDirectory;

            pathFoldersList.Items.Clear();

            for (int i = 0; i < document.PathFolders.Count; i++)
            {
                pathFoldersList.Items.Add(document.PathFolders[i]);
            }

            loading = false;
        }

        private static int Clamp(int value, int minimum, int maximum)
        {
            if (value < minimum)
            {
                return minimum;
            }

            if (value > maximum)
            {
                return maximum;
            }

            return value;
        }

        private void OnFieldChanged(object sender, EventArgs args)
        {
            if (loading || document == null)
            {
                return;
            }

            document.DefaultTimeoutSeconds = (int)defaultTimeoutBox.Value;
            document.MaxTimeoutSeconds = (int)maxTimeoutBox.Value;
            document.MaxOutputBytes = (int)maxOutputBox.Value;
            document.AllowHardLinkedFiles = allowHardLinksBox.Checked;
            document.AuditLogPath = auditLogBox.Text.Trim();
            document.TempDirectory = tempDirectoryBox.Text.Trim();
            RaiseChanged();
        }

        private void OnBrowseAuditLog(object sender, EventArgs args)
        {
            string picked = PathPickers.PickFileToWrite("Choose the audit log file", auditLogBox.Text);

            if (picked != null)
            {
                auditLogBox.Text = picked;
            }
        }

        private void OnBrowseTempDirectory(object sender, EventArgs args)
        {
            string picked = PathPickers.PickFolder("Choose the temp folder", tempDirectoryBox.Text);

            if (picked != null)
            {
                tempDirectoryBox.Text = picked;
            }
        }

        private void OnBrowseServer(object sender, EventArgs args)
        {
            string picked = PathPickers.PickExecutable("Choose nsexec-mcp.exe", serverExecutableBox.Text);

            if (picked != null)
            {
                serverExecutableBox.Text = picked;
            }
        }

        private void OnServerExecutableChanged(object sender, EventArgs args)
        {
            if (loading)
            {
                return;
            }

            if (ServerExecutableChanged != null)
            {
                ServerExecutableChanged(this, EventArgs.Empty);
            }
        }

        private void OnAddPathFolder(object sender, EventArgs args)
        {
            if (document == null)
            {
                return;
            }

            string picked = PathPickers.PickFolder("Choose a folder to add to PATH", null);

            if (picked == null)
            {
                return;
            }

            document.PathFolders.Add(picked);
            pathFoldersList.Items.Add(picked);
            RaiseChanged();
        }

        private void OnRemovePathFolder(object sender, EventArgs args)
        {
            if (document == null || pathFoldersList.SelectedIndex < 0)
            {
                return;
            }

            int index = pathFoldersList.SelectedIndex;
            document.PathFolders.RemoveAt(index);
            pathFoldersList.Items.RemoveAt(index);
            RaiseChanged();
        }

        private void RaiseChanged()
        {
            document.Modified = true;

            if (Changed != null)
            {
                Changed(this, EventArgs.Empty);
            }
        }
    }
}

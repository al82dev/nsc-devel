using System;
using System.Windows.Forms;
using NsExecMcp.ConfigUi.Model;

namespace NsExecMcp.ConfigUi.Ui
{
    // Editor of the authorized folders.
    public class RootsPanel : UserControl
    {
        private readonly ListView list;
        private TextBox pathBox;
        private CheckBox readBox;
        private CheckBox writeBox;
        private CheckBox executeBox;
        private TextBox commentBox;
        private ConfigDocument document;
        private bool loading;

        public RootsPanel()
        {
            Dock = DockStyle.Fill;
            Theme.ApplyContainer(this);

            TableLayoutPanel layout = Theme.CreateFormLayout(1);
            layout.RowCount = 3;
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));

            list = Theme.CreateListView();
            list.Columns.Add("Folder", 420);
            list.Columns.Add("Access", 80);
            list.Columns.Add("Comment", 240);
            list.SelectedIndexChanged += OnSelectionChanged;
            layout.Controls.Add(list, 0, 0);

            FlowLayoutPanel buttons = new FlowLayoutPanel();
            buttons.AutoSize = true;
            buttons.Dock = DockStyle.Fill;
            buttons.BackColor = Theme.Background;

            Button addButton = Theme.CreateButton("Add folder...");
            addButton.Click += OnAdd;
            buttons.Controls.Add(addButton);

            Button removeButton = Theme.CreateButton("Remove");
            removeButton.Click += OnRemove;
            buttons.Controls.Add(removeButton);

            layout.Controls.Add(buttons, 0, 1);
            layout.Controls.Add(BuildEditor(), 0, 2);
            Controls.Add(layout);
            SetEditorEnabled(false);
        }

        public event EventHandler Changed;

        private GroupBox BuildEditor()
        {
            GroupBox group = Theme.CreateGroup("Selected folder");
            group.Dock = DockStyle.Fill;
            group.AutoSize = true;
            group.AutoSizeMode = AutoSizeMode.GrowAndShrink;

            TableLayoutPanel layout = Theme.CreateFormLayout(3);
            layout.RowCount = 3;
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            layout.AutoSize = true;
            layout.AutoSizeMode = AutoSizeMode.GrowAndShrink;

            layout.Controls.Add(Theme.CreateLabel("Folder"), 0, 0);
            pathBox = Theme.CreateTextBox();
            pathBox.TextChanged += OnFieldChanged;
            layout.Controls.Add(pathBox, 1, 0);

            Button browse = Theme.CreateButton("Browse...");
            browse.Click += OnBrowse;
            layout.Controls.Add(browse, 2, 0);

            FlowLayoutPanel access = new FlowLayoutPanel();
            access.AutoSize = true;
            access.BackColor = Theme.Background;

            readBox = Theme.CreateCheckBox("Read");
            readBox.Checked = true;
            readBox.Enabled = false;
            access.Controls.Add(readBox);

            writeBox = Theme.CreateCheckBox("Write");
            writeBox.CheckedChanged += OnFieldChanged;
            access.Controls.Add(writeBox);

            executeBox = Theme.CreateCheckBox("Execute (a whitelisted image may live here)");
            executeBox.CheckedChanged += OnFieldChanged;
            access.Controls.Add(executeBox);

            layout.Controls.Add(Theme.CreateLabel("Access"), 0, 1);
            layout.Controls.Add(access, 1, 1);

            layout.Controls.Add(Theme.CreateLabel("Comment"), 0, 2);
            commentBox = Theme.CreateTextBox();
            commentBox.TextChanged += OnFieldChanged;
            layout.Controls.Add(commentBox, 1, 2);

            group.Controls.Add(layout);
            return group;
        }

        public void Bind(ConfigDocument value)
        {
            document = value;
            Reload();
        }

        private void Reload()
        {
            loading = true;
            list.Items.Clear();

            if (document != null)
            {
                for (int i = 0; i < document.Roots.Count; i++)
                {
                    list.Items.Add(BuildRow(document.Roots[i]));
                }
            }

            loading = false;
            LoadSelection();
        }

        private static ListViewItem BuildRow(RootItem entry)
        {
            ListViewItem row = new ListViewItem(entry.Path == null ? "" : entry.Path);
            row.SubItems.Add(entry.DescribeAccess());
            row.SubItems.Add(entry.Comment == null ? "" : entry.Comment);
            row.Tag = entry;
            return row;
        }

        private RootItem GetSelected()
        {
            if (list.SelectedItems.Count == 0)
            {
                return null;
            }

            return list.SelectedItems[0].Tag as RootItem;
        }

        private void LoadSelection()
        {
            RootItem entry = GetSelected();
            loading = true;

            if (entry == null)
            {
                pathBox.Text = "";
                commentBox.Text = "";
                writeBox.Checked = false;
                executeBox.Checked = false;
                SetEditorEnabled(false);
            }
            else
            {
                pathBox.Text = entry.Path == null ? "" : entry.Path;
                commentBox.Text = entry.Comment == null ? "" : entry.Comment;
                writeBox.Checked = entry.Write;
                executeBox.Checked = entry.Execute;
                SetEditorEnabled(true);
            }

            loading = false;
        }

        private void SetEditorEnabled(bool enabled)
        {
            readBox.Enabled = false;
            pathBox.Enabled = enabled;
            commentBox.Enabled = enabled;
            writeBox.Enabled = enabled;
            executeBox.Enabled = enabled;
        }

        private void OnSelectionChanged(object sender, EventArgs args)
        {
            if (loading)
            {
                return;
            }

            LoadSelection();
        }

        private void OnFieldChanged(object sender, EventArgs args)
        {
            if (loading)
            {
                return;
            }

            RootItem entry = GetSelected();

            if (entry == null)
            {
                return;
            }

            entry.Path = pathBox.Text;
            entry.Comment = commentBox.Text;
            entry.Read = true;
            entry.Write = writeBox.Checked;
            entry.Execute = executeBox.Checked;

            ListViewItem row = list.SelectedItems[0];
            row.SubItems[0].Text = entry.Path;
            row.SubItems[1].Text = entry.DescribeAccess();
            row.SubItems[2].Text = entry.Comment;
            RaiseChanged();
        }

        private void OnBrowse(object sender, EventArgs args)
        {
            RootItem entry = GetSelected();

            if (entry == null)
            {
                return;
            }

            string picked = PathPickers.PickFolder("Choose an authorized folder", entry.Path);

            if (picked == null)
            {
                return;
            }

            pathBox.Text = picked;
        }

        private void OnAdd(object sender, EventArgs args)
        {
            if (document == null)
            {
                return;
            }

            string picked = PathPickers.PickFolder("Choose an authorized folder", null);

            if (picked == null)
            {
                return;
            }

            RootItem entry = new RootItem();
            entry.Path = picked;
            entry.Read = true;
            document.Roots.Add(entry);

            ListViewItem row = BuildRow(entry);
            list.Items.Add(row);
            row.Selected = true;
            list.Focus();
            RaiseChanged();
        }

        private void OnRemove(object sender, EventArgs args)
        {
            RootItem entry = GetSelected();

            if (entry == null || document == null)
            {
                return;
            }

            document.Roots.Remove(entry);
            list.Items.Remove(list.SelectedItems[0]);
            LoadSelection();
            RaiseChanged();
        }

        private void RaiseChanged()
        {
            if (document != null)
            {
                document.Modified = true;
            }

            if (Changed != null)
            {
                Changed(this, EventArgs.Empty);
            }
        }
    }
}

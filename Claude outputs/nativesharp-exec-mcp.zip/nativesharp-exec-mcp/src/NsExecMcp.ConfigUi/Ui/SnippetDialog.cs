using System;
using System.Drawing;
using System.Text;
using System.Text.Json;
using System.Windows.Forms;

namespace NsExecMcp.ConfigUi.Ui
{
    // Shows the block to paste into the desktop application MCP configuration.
    public class SnippetDialog : Form
    {
        private readonly TextBox snippetBox;

        public SnippetDialog(string serverExecutablePath, string configPath)
        {
            Text = "MCP server entry";
            StartPosition = FormStartPosition.CenterParent;
            ClientSize = new Size(640, 320);
            MinimizeBox = false;
            MaximizeBox = false;
            Theme.ApplyForm(this);

            Label hint = Theme.CreateHint("Paste this into the mcpServers section of the desktop "
                                          + "application configuration.");
            hint.Location = new Point(12, 12);
            Controls.Add(hint);

            snippetBox = new TextBox();
            snippetBox.Multiline = true;
            snippetBox.ReadOnly = true;
            snippetBox.ScrollBars = ScrollBars.Both;
            snippetBox.WordWrap = false;
            snippetBox.BackColor = Theme.Surface;
            snippetBox.ForeColor = Theme.Text;
            snippetBox.BorderStyle = BorderStyle.FixedSingle;
            snippetBox.Font = Theme.CreateMonospaceFont();
            snippetBox.Location = new Point(12, 40);
            snippetBox.Size = new Size(616, 230);
            snippetBox.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
            snippetBox.Text = BuildSnippet(serverExecutablePath, configPath);
            Controls.Add(snippetBox);

            Button copyButton = Theme.CreateButton("Copy");
            copyButton.Location = new Point(452, 280);
            copyButton.Width = 84;
            copyButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            copyButton.Click += OnCopy;
            Controls.Add(copyButton);

            Button closeButton = Theme.CreateButton("Close");
            closeButton.Location = new Point(544, 280);
            closeButton.Width = 84;
            closeButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            closeButton.DialogResult = DialogResult.OK;
            Controls.Add(closeButton);

            AcceptButton = closeButton;
        }

        private static string BuildSnippet(string serverExecutablePath, string configPath)
        {
            string executable = string.IsNullOrWhiteSpace(serverExecutablePath)
                                ? "C:\\nsexec-mcp\\nsexec-mcp.exe" : serverExecutablePath;
            string config = string.IsNullOrWhiteSpace(configPath)
                            ? "C:\\nsexec-mcp\\nsexec-mcp.config.json" : configPath;

            StringBuilder builder = new StringBuilder();
            builder.AppendLine("{");
            builder.AppendLine("  \"mcpServers\": {");
            builder.AppendLine("    \"nsexec\": {");
            builder.AppendLine("      \"command\": " + JsonSerializer.Serialize(executable) + ",");
            builder.AppendLine("      \"args\": [");
            builder.AppendLine("        \"--config\",");
            builder.AppendLine("        " + JsonSerializer.Serialize(config));
            builder.AppendLine("      ]");
            builder.AppendLine("    }");
            builder.AppendLine("  }");
            builder.AppendLine("}");
            return builder.ToString();
        }

        private void OnCopy(object sender, EventArgs args)
        {
            try
            {
                Clipboard.SetText(snippetBox.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Copy", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}

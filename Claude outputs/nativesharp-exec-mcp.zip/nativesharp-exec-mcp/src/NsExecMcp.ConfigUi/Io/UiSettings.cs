namespace NsExecMcp.ConfigUi.Io
{
    // Editor preferences, kept outside the policy file.
    public class UiSettings
    {
        public string ServerExecutablePath { get; set; }

        public string LastConfigPath { get; set; }
    }
}

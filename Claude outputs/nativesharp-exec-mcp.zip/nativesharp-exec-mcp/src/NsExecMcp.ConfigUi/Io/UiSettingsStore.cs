using System;
using System.IO;
using System.Text;
using System.Text.Json;

namespace NsExecMcp.ConfigUi.Io
{
    // Loads and saves the editor preferences in the user profile.
    public static class UiSettingsStore
    {
        public static string GetSettingsPath()
        {
            string folder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            return Path.Combine(folder, "nsexec-mcp", "config-ui.json");
        }

        public static UiSettings Load()
        {
            UiSettings settings = new UiSettings();
            string path = GetSettingsPath();

            try
            {
                if (!File.Exists(path))
                {
                    return settings;
                }

                using (JsonDocument document = JsonDocument.Parse(File.ReadAllText(path)))
                {
                    JsonElement root = document.RootElement;
                    JsonElement element;

                    if (root.TryGetProperty("serverExecutablePath", out element)
                        && element.ValueKind == JsonValueKind.String)
                    {
                        settings.ServerExecutablePath = element.GetString();
                    }

                    if (root.TryGetProperty("lastConfigPath", out element)
                        && element.ValueKind == JsonValueKind.String)
                    {
                        settings.LastConfigPath = element.GetString();
                    }
                }
            }
            catch (Exception)
            {
                // Preferences are best effort.
            }

            return settings;
        }

        public static void Save(UiSettings settings)
        {
            try
            {
                string path = GetSettingsPath();
                string folder = Path.GetDirectoryName(path);

                if (!Directory.Exists(folder))
                {
                    Directory.CreateDirectory(folder);
                }

                StringBuilder builder = new StringBuilder();
                builder.Append("{\"serverExecutablePath\":");
                builder.Append(JsonSerializer.Serialize(settings.ServerExecutablePath));
                builder.Append(",\"lastConfigPath\":");
                builder.Append(JsonSerializer.Serialize(settings.LastConfigPath));
                builder.Append('}');
                File.WriteAllText(path, builder.ToString(), new UTF8Encoding(false));
            }
            catch (Exception)
            {
                // Preferences are best effort.
            }
        }
    }
}

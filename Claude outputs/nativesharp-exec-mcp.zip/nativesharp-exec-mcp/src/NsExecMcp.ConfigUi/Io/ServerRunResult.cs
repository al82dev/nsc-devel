namespace NsExecMcp.ConfigUi.Io
{
    // Outcome of running the server executable in one of its diagnostic modes.
    public class ServerRunResult
    {
        public ServerRunResult(int exitCode, string output)
        {
            ExitCode = exitCode;
            Output = output;
        }

        public int ExitCode { get; private set; }

        // Standard output and standard error joined, in the order they were produced.
        public string Output { get; private set; }

        public bool Succeeded
        {
            get { return ExitCode == 0; }
        }
    }
}

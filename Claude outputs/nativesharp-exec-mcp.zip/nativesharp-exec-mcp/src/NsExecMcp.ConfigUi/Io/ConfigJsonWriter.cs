using System;
using System.IO;
using System.Text;
using System.Text.Json;
using NsExecMcp.ConfigUi.Model;

namespace NsExecMcp.ConfigUi.Io
{
    // Writes the document back as an indented policy file.
    public static class ConfigJsonWriter
    {
        public static void Write(ConfigDocument document, string path)
        {
            string text = Serialize(document);
            File.WriteAllText(path, text, new UTF8Encoding(false));
        }

        public static string Serialize(ConfigDocument document)
        {
            using (MemoryStream stream = new MemoryStream())
            {
                JsonWriterOptions options = new JsonWriterOptions();
                options.Indented = true;

                using (Utf8JsonWriter writer = new Utf8JsonWriter(stream, options))
                {
                    writer.WriteStartObject();
                    WriteRoots(writer, document);
                    WritePrograms(writer, document);
                    WriteGeneral(writer, document);
                    writer.WriteEndObject();
                }

                return Encoding.UTF8.GetString(stream.ToArray());
            }
        }

        private static void WriteRoots(Utf8JsonWriter writer, ConfigDocument document)
        {
            writer.WriteStartArray("roots");

            for (int i = 0; i < document.Roots.Count; i++)
            {
                RootItem entry = document.Roots[i];
                writer.WriteStartObject();
                writer.WriteString("path", entry.Path == null ? "" : entry.Path);
                writer.WriteString("access", entry.ToAccessString());

                if (!string.IsNullOrWhiteSpace(entry.Comment))
                {
                    writer.WriteString("comment", entry.Comment);
                }

                writer.WriteEndObject();
            }

            writer.WriteEndArray();
        }

        private static void WritePrograms(Utf8JsonWriter writer, ConfigDocument document)
        {
            writer.WriteStartArray("programs");

            for (int i = 0; i < document.Programs.Count; i++)
            {
                ProgramItem entry = document.Programs[i];
                writer.WriteStartObject();
                writer.WriteString("id", entry.Id == null ? "" : entry.Id);
                writer.WriteString("path", entry.Path == null ? "" : entry.Path);

                if (!string.IsNullOrWhiteSpace(entry.Description))
                {
                    writer.WriteString("description", entry.Description);
                }

                if (!string.IsNullOrWhiteSpace(entry.DefaultWorkingDirectory))
                {
                    writer.WriteString("defaultWorkingDirectory", entry.DefaultWorkingDirectory);
                }

                if (entry.FixedArguments.Count > 0)
                {
                    writer.WriteStartArray("fixedArguments");

                    for (int j = 0; j < entry.FixedArguments.Count; j++)
                    {
                        writer.WriteStringValue(entry.FixedArguments[j]);
                    }

                    writer.WriteEndArray();
                }

                if (!entry.AllowArgumentsFromClient)
                {
                    writer.WriteBoolean("allowArgumentsFromClient", false);
                }

                if (entry.AcknowledgeInterpreter)
                {
                    writer.WriteBoolean("acknowledgeInterpreter", true);
                }

                if (entry.TimeoutSeconds > 0)
                {
                    writer.WriteNumber("timeoutSeconds", entry.TimeoutSeconds);
                }

                if (entry.MaxOutputBytes > 0)
                {
                    writer.WriteNumber("maxOutputBytes", entry.MaxOutputBytes);
                }

                if (!string.IsNullOrWhiteSpace(entry.Sha256))
                {
                    writer.WriteString("sha256", entry.Sha256.Trim());
                }

                if (entry.Environment.Count > 0)
                {
                    writer.WriteStartObject("environment");

                    for (int j = 0; j < entry.Environment.Count; j++)
                    {
                        EnvironmentItem variable = entry.Environment[j];

                        if (string.IsNullOrWhiteSpace(variable.Name))
                        {
                            continue;
                        }

                        writer.WriteString(variable.Name, variable.Value == null ? "" : variable.Value);
                    }

                    writer.WriteEndObject();
                }

                writer.WriteEndObject();
            }

            writer.WriteEndArray();
        }

        private static void WriteGeneral(Utf8JsonWriter writer, ConfigDocument document)
        {
            if (document.PathFolders.Count > 0)
            {
                writer.WriteStartArray("pathFolders");

                for (int i = 0; i < document.PathFolders.Count; i++)
                {
                    writer.WriteStringValue(document.PathFolders[i]);
                }

                writer.WriteEndArray();
            }

            if (!string.IsNullOrWhiteSpace(document.TempDirectory))
            {
                writer.WriteString("tempDirectory", document.TempDirectory);
            }

            if (!string.IsNullOrWhiteSpace(document.AuditLogPath))
            {
                writer.WriteString("auditLogPath", document.AuditLogPath);
            }

            writer.WriteNumber("defaultTimeoutSeconds", document.DefaultTimeoutSeconds);
            writer.WriteNumber("maxTimeoutSeconds", document.MaxTimeoutSeconds);
            writer.WriteNumber("maxOutputBytes", document.MaxOutputBytes);
            writer.WriteBoolean("allowHardLinkedFiles", document.AllowHardLinkedFiles);
        }
    }
}

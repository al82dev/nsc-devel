using System;
using System.IO;
using System.Text.Json;
using NsExecMcp.ConfigUi.Model;

namespace NsExecMcp.ConfigUi.Io
{
    // Reads a policy file into the editable document. Unknown properties are ignored, so a file
    // written by hand keeps working, but saving rewrites the file with the known keys only.
    public static class ConfigJsonReader
    {
        public static ConfigDocument Read(string path)
        {
            string text = File.ReadAllText(path);
            ConfigDocument document = new ConfigDocument();

            JsonDocumentOptions options = new JsonDocumentOptions();
            options.AllowTrailingCommas = true;
            options.CommentHandling = JsonCommentHandling.Skip;

            using (JsonDocument json = JsonDocument.Parse(text, options))
            {
                JsonElement root = json.RootElement;

                if (root.ValueKind != JsonValueKind.Object)
                {
                    throw new InvalidDataException("the root of the file must be a JSON object.");
                }

                ReadRoots(root, document);
                ReadPrograms(root, document);
                ReadGeneral(root, document);
            }

            document.FilePath = path;
            document.Modified = false;
            return document;
        }

        private static void ReadRoots(JsonElement root, ConfigDocument document)
        {
            JsonElement roots;

            if (!root.TryGetProperty("roots", out roots) || roots.ValueKind != JsonValueKind.Array)
            {
                return;
            }

            foreach (JsonElement item in roots.EnumerateArray())
            {
                if (item.ValueKind != JsonValueKind.Object)
                {
                    continue;
                }

                RootItem entry = new RootItem();
                entry.Path = ReadString(item, "path");
                entry.SetAccessFromString(ReadString(item, "access"));
                entry.Comment = ReadString(item, "comment");
                document.Roots.Add(entry);
            }
        }

        private static void ReadPrograms(JsonElement root, ConfigDocument document)
        {
            JsonElement programs;

            if (!root.TryGetProperty("programs", out programs) || programs.ValueKind != JsonValueKind.Array)
            {
                return;
            }

            foreach (JsonElement item in programs.EnumerateArray())
            {
                if (item.ValueKind != JsonValueKind.Object)
                {
                    continue;
                }

                ProgramItem entry = new ProgramItem();
                entry.Id = ReadString(item, "id");
                entry.Path = ReadString(item, "path");
                entry.Description = ReadString(item, "description");
                entry.DefaultWorkingDirectory = ReadString(item, "defaultWorkingDirectory");
                entry.Sha256 = ReadString(item, "sha256");
                entry.TimeoutSeconds = ReadInt(item, "timeoutSeconds");
                entry.MaxOutputBytes = ReadInt(item, "maxOutputBytes");
                entry.AllowArgumentsFromClient = ReadBool(item, "allowArgumentsFromClient", true);
                entry.AcknowledgeInterpreter = ReadBool(item, "acknowledgeInterpreter", false);

                JsonElement element;

                if (item.TryGetProperty("fixedArguments", out element) && element.ValueKind == JsonValueKind.Array)
                {
                    foreach (JsonElement argument in element.EnumerateArray())
                    {
                        if (argument.ValueKind == JsonValueKind.String)
                        {
                            entry.FixedArguments.Add(argument.GetString());
                        }
                    }
                }

                if (item.TryGetProperty("environment", out element) && element.ValueKind == JsonValueKind.Object)
                {
                    foreach (JsonProperty property in element.EnumerateObject())
                    {
                        if (property.Value.ValueKind == JsonValueKind.String)
                        {
                            entry.Environment.Add(new EnvironmentItem(property.Name, property.Value.GetString()));
                        }
                    }
                }

                document.Programs.Add(entry);
            }
        }

        private static void ReadGeneral(JsonElement root, ConfigDocument document)
        {
            JsonElement element;

            if (root.TryGetProperty("pathFolders", out element) && element.ValueKind == JsonValueKind.Array)
            {
                foreach (JsonElement item in element.EnumerateArray())
                {
                    if (item.ValueKind == JsonValueKind.String)
                    {
                        document.PathFolders.Add(item.GetString());
                    }
                }
            }

            document.TempDirectory = ReadString(root, "tempDirectory");
            document.AuditLogPath = ReadString(root, "auditLogPath");

            int value = ReadInt(root, "defaultTimeoutSeconds");

            if (value > 0)
            {
                document.DefaultTimeoutSeconds = value;
            }

            value = ReadInt(root, "maxTimeoutSeconds");

            if (value > 0)
            {
                document.MaxTimeoutSeconds = value;
            }

            value = ReadInt(root, "maxOutputBytes");

            if (value > 0)
            {
                document.MaxOutputBytes = value;
            }

            document.AllowHardLinkedFiles = ReadBool(root, "allowHardLinkedFiles", false);
        }

        private static string ReadString(JsonElement item, string name)
        {
            JsonElement element;

            if (item.TryGetProperty(name, out element) && element.ValueKind == JsonValueKind.String)
            {
                return element.GetString();
            }

            return null;
        }

        private static int ReadInt(JsonElement item, string name)
        {
            JsonElement element;

            if (item.TryGetProperty(name, out element) && element.ValueKind == JsonValueKind.Number)
            {
                return element.GetInt32();
            }

            return 0;
        }

        private static bool ReadBool(JsonElement item, string name, bool fallback)
        {
            JsonElement element;

            if (!item.TryGetProperty(name, out element))
            {
                return fallback;
            }

            if (element.ValueKind == JsonValueKind.True)
            {
                return true;
            }

            if (element.ValueKind == JsonValueKind.False)
            {
                return false;
            }

            return fallback;
        }
    }
}

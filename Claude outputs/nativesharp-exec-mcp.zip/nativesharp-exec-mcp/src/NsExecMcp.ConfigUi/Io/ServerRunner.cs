using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;

namespace NsExecMcp.ConfigUi.Io
{
    // Runs nsexec-mcp.exe in its diagnostic modes, so the editor validates against the real
    // policy engine instead of repeating its rules.
    public class ServerRunner
    {
        private const int TimeoutMilliseconds = 60000;

        private readonly string executablePath;

        public ServerRunner(string executablePath)
        {
            this.executablePath = executablePath;
        }

        public string ExecutablePath
        {
            get { return executablePath; }
        }

        public bool IsAvailable
        {
            get { return !string.IsNullOrWhiteSpace(executablePath) && File.Exists(executablePath); }
        }

        public ServerRunResult Check(string configFile)
        {
            List<string> arguments = new List<string>();
            arguments.Add("--config");
            arguments.Add(configFile);
            arguments.Add("--check");
            return Run(arguments);
        }

        public ServerRunResult Probe(string configFile, string path)
        {
            List<string> arguments = new List<string>();
            arguments.Add("--config");
            arguments.Add(configFile);
            arguments.Add("--probe");
            arguments.Add(path);
            return Run(arguments);
        }

        public ServerRunResult Hash(string path)
        {
            List<string> arguments = new List<string>();
            arguments.Add("--hash");
            arguments.Add(path);
            return Run(arguments);
        }

        public ServerRunResult CallTool(string configFile, string tool, string jsonArguments)
        {
            List<string> arguments = new List<string>();
            arguments.Add("--config");
            arguments.Add(configFile);
            arguments.Add("--call");
            arguments.Add(tool);

            if (!string.IsNullOrWhiteSpace(jsonArguments))
            {
                arguments.Add("--json");
                arguments.Add(jsonArguments);
            }

            return Run(arguments);
        }

        private ServerRunResult Run(List<string> arguments)
        {
            if (!IsAvailable)
            {
                return new ServerRunResult(-1, "The server executable is not set or does not exist."
                                               + Environment.NewLine
                                               + "Set it in the General tab before validating.");
            }

            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = executablePath;
            startInfo.UseShellExecute = false;
            startInfo.CreateNoWindow = true;
            startInfo.RedirectStandardOutput = true;
            startInfo.RedirectStandardError = true;
            startInfo.WorkingDirectory = Path.GetDirectoryName(executablePath);

            for (int i = 0; i < arguments.Count; i++)
            {
                startInfo.ArgumentList.Add(arguments[i]);
            }

            StringBuilder collected = new StringBuilder();

            try
            {
                using (Process process = new Process())
                {
                    process.StartInfo = startInfo;

                    process.OutputDataReceived += delegate (object sender, DataReceivedEventArgs args)
                    {
                        if (args.Data != null)
                        {
                            lock (collected)
                            {
                                collected.AppendLine(args.Data);
                            }
                        }
                    };

                    process.ErrorDataReceived += delegate (object sender, DataReceivedEventArgs args)
                    {
                        if (args.Data != null)
                        {
                            lock (collected)
                            {
                                collected.AppendLine(args.Data);
                            }
                        }
                    };

                    process.Start();
                    process.BeginOutputReadLine();
                    process.BeginErrorReadLine();

                    if (!process.WaitForExit(TimeoutMilliseconds))
                    {
                        try
                        {
                            process.Kill(true);
                        }
                        catch (Exception)
                        {
                            // Already gone.
                        }

                        return new ServerRunResult(-1, collected.ToString() + Environment.NewLine
                                                       + "The server did not answer in time.");
                    }

                    return new ServerRunResult(process.ExitCode, collected.ToString());
                }
            }
            catch (Exception ex)
            {
                return new ServerRunResult(-1, "Could not run the server: " + ex.Message);
            }
        }
    }
}

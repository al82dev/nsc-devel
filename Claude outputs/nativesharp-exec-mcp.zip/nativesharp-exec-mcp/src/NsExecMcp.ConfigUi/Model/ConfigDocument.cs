using System.Collections.Generic;

namespace NsExecMcp.ConfigUi.Model
{
    // Whole configuration being edited, plus the state of the editing session.
    public class ConfigDocument
    {
        public ConfigDocument()
        {
            Roots = new List<RootItem>();
            Programs = new List<ProgramItem>();
            PathFolders = new List<string>();
            DefaultTimeoutSeconds = 120;
            MaxTimeoutSeconds = 900;
            MaxOutputBytes = 262144;
            AllowHardLinkedFiles = false;
        }

        public List<RootItem> Roots { get; private set; }

        public List<ProgramItem> Programs { get; private set; }

        public List<string> PathFolders { get; private set; }

        public string TempDirectory { get; set; }

        public string AuditLogPath { get; set; }

        public int DefaultTimeoutSeconds { get; set; }

        public int MaxTimeoutSeconds { get; set; }

        public int MaxOutputBytes { get; set; }

        public bool AllowHardLinkedFiles { get; set; }

        // File the document was loaded from or last saved to. Null for a new document.
        public string FilePath { get; set; }

        public bool Modified { get; set; }

        public ProgramItem FindProgram(string id)
        {
            for (int i = 0; i < Programs.Count; i++)
            {
                if (string.Equals(Programs[i].Id, id, System.StringComparison.Ordinal))
                {
                    return Programs[i];
                }
            }

            return null;
        }
    }
}

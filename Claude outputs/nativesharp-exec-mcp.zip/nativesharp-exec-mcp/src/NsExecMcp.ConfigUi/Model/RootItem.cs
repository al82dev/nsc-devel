namespace NsExecMcp.ConfigUi.Model
{
    // One authorized folder as edited in the user interface.
    public class RootItem
    {
        public RootItem()
        {
            Read = true;
        }

        public string Path { get; set; }

        // Read is mandatory in the policy, so it is always true here.
        public bool Read { get; set; }

        public bool Write { get; set; }

        public bool Execute { get; set; }

        public string Comment { get; set; }

        public string DescribeAccess()
        {
            string text = "";
            text += Read ? "r" : "-";
            text += Write ? "w" : "-";
            text += Execute ? "x" : "-";
            return text;
        }

        // Compact form written to the configuration file.
        public string ToAccessString()
        {
            string text = "";

            if (Read)
            {
                text += "r";
            }

            if (Write)
            {
                text += "w";
            }

            if (Execute)
            {
                text += "x";
            }

            return text;
        }

        public void SetAccessFromString(string access)
        {
            Read = false;
            Write = false;
            Execute = false;

            if (string.IsNullOrEmpty(access))
            {
                Read = true;
                return;
            }

            string value = access.ToLowerInvariant();

            if (value.IndexOf(',') >= 0)
            {
                Read = value.IndexOf("read") >= 0;
                Write = value.IndexOf("write") >= 0;
                Execute = value.IndexOf("execute") >= 0;
                return;
            }

            for (int i = 0; i < value.Length; i++)
            {
                char c = value[i];

                if (c == 'r')
                {
                    Read = true;
                }
                else if (c == 'w')
                {
                    Write = true;
                }
                else if (c == 'x')
                {
                    Execute = true;
                }
            }
        }
    }
}

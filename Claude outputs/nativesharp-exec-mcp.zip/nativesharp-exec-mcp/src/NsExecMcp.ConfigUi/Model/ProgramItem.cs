using System.Collections.Generic;

namespace NsExecMcp.ConfigUi.Model
{
    // One whitelisted program as edited in the user interface.
    public class ProgramItem
    {
        public ProgramItem()
        {
            FixedArguments = new List<string>();
            Environment = new List<EnvironmentItem>();
            AllowArgumentsFromClient = true;
        }

        public string Id { get; set; }

        public string Path { get; set; }

        public string Description { get; set; }

        public string DefaultWorkingDirectory { get; set; }

        public List<string> FixedArguments { get; private set; }

        public bool AllowArgumentsFromClient { get; set; }

        public bool AcknowledgeInterpreter { get; set; }

        public List<EnvironmentItem> Environment { get; private set; }

        // Zero means use the global value.
        public int TimeoutSeconds { get; set; }

        // Zero means use the global value.
        public int MaxOutputBytes { get; set; }

        public string Sha256 { get; set; }
    }
}

namespace NsExecMcp.ConfigUi.Model
{
    // One environment variable of a program entry.
    public class EnvironmentItem
    {
        public EnvironmentItem()
        {
        }

        public EnvironmentItem(string name, string value)
        {
            Name = name;
            Value = value;
        }

        public string Name { get; set; }

        public string Value { get; set; }
    }
}

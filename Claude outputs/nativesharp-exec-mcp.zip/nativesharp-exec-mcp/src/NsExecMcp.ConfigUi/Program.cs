using System;
using System.Windows.Forms;
using NsExecMcp.ConfigUi.Ui;

namespace NsExecMcp.ConfigUi
{
    // Entry point of the policy editor.
    public static class Program
    {
        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);
            Application.Run(new MainForm());
        }
    }
}

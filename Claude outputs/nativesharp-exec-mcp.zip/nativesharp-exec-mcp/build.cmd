@echo off
rem Builds the MCP server and the policy editor into .\publish
setlocal

set CONFIGURATION=Release
set OUTPUT=%~dp0publish

dotnet publish "%~dp0src\NsExecMcp\NsExecMcp.csproj" -c %CONFIGURATION% -r win-x64 ^
    --self-contained false -p:PublishSingleFile=true -o "%OUTPUT%"

if errorlevel 1 (
    echo server build failed
    exit /b 1
)

dotnet publish "%~dp0src\NsExecMcp.ConfigUi\NsExecMcp.ConfigUi.csproj" -c %CONFIGURATION% -r win-x64 ^
    --self-contained false -p:PublishSingleFile=true -o "%OUTPUT%"

if errorlevel 1 (
    echo editor build failed
    exit /b 1
)

echo.
echo built into %OUTPUT%
echo   nsexec-mcp.exe          the MCP server
echo   nsexec-mcp-config.exe   the policy editor
endlocal

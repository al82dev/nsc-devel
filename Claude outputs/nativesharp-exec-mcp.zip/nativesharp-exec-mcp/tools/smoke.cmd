@echo off
rem Feeds a few JSON-RPC messages to the server and prints the raw answers.
rem Usage: smoke.cmd <path to nsexec-mcp.exe> <path to config>
setlocal

if "%~1"=="" (
    echo usage: smoke.cmd ^<nsexec-mcp.exe^> ^<config.json^>
    exit /b 2
)

type "%~dp0smoke.jsonl" | "%~1" --config "%~2"
endlocal

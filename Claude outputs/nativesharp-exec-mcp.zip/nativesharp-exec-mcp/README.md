# nsexec-mcp

A local MCP server (stdio) that runs a short list of whitelisted programs inside a short list
of authorized folders, and returns exit code, stdout and stderr.

It is deliberately not a shell. There is no command line to interpret, no `&&`, no `|`, no `>`.
The client names a program by id and passes an argument vector; the server passes that vector to
`CreateProcess` one element at a time.

## Tools exposed

| tool | purpose |
|---|---|
| `run_program` | Runs a whitelisted program. Input: `program`, `args`, `cwd`, `timeoutSeconds`. Output: exit code, duration, stdout, stderr, truncation flags. |
| `list_programs` | The whitelisted programs with their fixed arguments, default working directory and limits. |
| `get_policy` | Authorized folders with permissions, limits, audit log location. |
| `read_audit_log` | The last invocations, one JSON object per line. |

## Threat model and what each defence does

**1. Executable whitelist.** The client can only name an id declared in the configuration. It
never passes a path. Known interpreters (`cmd`, `powershell`, `pwsh`, `wsl`, `bash`, `python`,
`node`, `wscript`, `cscript`, `mshta`, `rundll32`, `regsvr32`, `dotnet`, `msbuild`, `certutil`,
`curl`, `reg`, `sc`, and others) are refused outright unless the entry sets
`acknowledgeInterpreter: true`, `allowArgumentsFromClient: false` and a non empty
`fixedArguments` list — an interpreter that cannot receive an argument from the client is the
only shape in which one is accepted. Script files (`.bat`, `.cmd`, `.ps1`, `.vbs`, `.js`, `.py`,
`.sh`) can never be the image, because launching one always means launching an interpreter.

**2. No shell interpretation.** `UseShellExecute = false`, `ArgumentList` rather than a
concatenated command line, `CreateNoWindow = true`, stdin closed immediately. Redirection and
chaining operators are ordinary characters in an argument, and reach the child as such.

**3. Canonicalization before comparison.** Every path goes through, in this order:

- rejection of UNC (`\\server\share`), `\\?\`, `\\.\`, wildcards, control characters,
  alternate data streams (`file.ns:stream`), reserved device names (`CON`, `NUL`, `COM1`…)
  and drive relative forms (`X:foo`), which depend on the per drive current directory;
- `Path.GetFullPath` to collapse `.` and `..`;
- `QueryDosDevice` to resolve substituted drives (`subst`), following chains up to 16 deep —
  `X:\SaruEmu` is compared as the directory it really is;
- `GetLongPathName` to expand 8.3 short names (`PROGRA~1`), applied to the deepest existing
  ancestor so paths that do not exist yet are still normalized;
- link resolution component by component (`ResolveLinkTarget`), which covers symbolic links,
  junctions and mount points, with a depth limit;
- a second pass of subst resolution and `GetFullPath`, in case a link landed on a substituted
  drive.

Comparison against the roots is ordinal, case insensitive, and boundary aware, so `C:\native-sharpX`
does not match the root `C:\native-sharp`. Nested roots are allowed and the most specific one wins,
so a read only folder can sit inside a writable one.

**4. Hard links.** `GetFileInformationByHandle` reports `NumberOfLinks`. A data path with more than
one hard link is refused, because the same bytes are reachable under another name that may be
outside the jail. This does **not** apply to the image of a whitelisted program: a second hard link
does not change which code runs, and installers legitimately hard link the same executable into
several folders (Git for Windows ships the same `git.exe` in `cmd\`, `bin\` and `mingw64\bin\`).
Image integrity is pinned with `sha256` instead. Set `allowHardLinkedFiles: true` to turn the check
off for data paths too.

**5. Fixed environment.** The child environment is built from nothing:
`startInfo.Environment.Clear()` and then only `SystemRoot`, `windir`,
`NUMBER_OF_PROCESSORS`, `PROCESSOR_ARCHITECTURE`, a `PATH` made of the folders of the whitelisted
programs plus `System32`, `PATHEXT=.EXE`, `TEMP`/`TMP` pointing at `tempDirectory`, and the
variables declared for that program. The configuration cannot set `PATH`, `PATHEXT`, `COMSPEC`,
`SystemRoot`, `windir`, `TEMP`, `TMP`, `__COMPAT_LAYER`, `COR_ENABLE_PROFILING`, `COR_PROFILER`
or `DOTNET_STARTUP_HOOKS`, and any absolute path inside a declared variable must itself be inside
an authorized folder — a variable such as `NSC_LLD_LINK` cannot point at a linker outside the jail.

**6. Per folder permissions.** `r`, `w`, `x`. Read is mandatory. `x` only means that the image of a
whitelisted program may live there; it never allows launching anything else.

**7. Ceilings and audit.** Per call timeout bounded by `maxTimeoutSeconds`, process tree killed on
expiry (`Process.Kill(true)`), output capped by `maxOutputBytes` per stream with an explicit
truncation flag, and one JSON line per call in the audit log — accepted and rejected alike, with
timestamp, program, image, full argv, cwd, outcome, reason, exit code, duration.

**8. Arguments.** Every argument is checked for control characters and length, and every path that
appears inside one is canonicalized and required to be inside the jail — including the form
`-o:C:\out\file`, response files (`@file`), and relative paths resolved against the working
directory. UNC inside an argument is refused.

## What this does NOT give you

Say it plainly: this is a policy layer in front of `CreateProcess`, not an operating system
sandbox. Once a whitelisted program is running, it runs with the rights of the user who launched
the server, and nothing here stops that program from writing wherever that user can write. The
jail restricts **what can be launched and what it is told**, not what a launched process is
capable of. That is why the executable whitelist matters more than the path filter.

To close that gap the hardening is outside this program: run the server under a dedicated account
with ACLs that actually deny the folders you care about, or put the child in a Job object /
AppContainer. Both are worth doing if the compiler being run is not trusted; if `nsc.exe` is your
own build, the whitelist plus this policy is the realistic line.

Two smaller limitations worth knowing: argument quoting follows the `CommandLineToArgvW`
convention that `ArgumentList` implements, so a program with a non standard parser may see
arguments differently; and the audit log is warned about but not protected if you place it inside
a writable authorized folder.

## Configuration

See `config/nsexec-mcp.config.example.json`. Keys:

- `roots[]`: `path`, `access` (`"rw"`, `"rx"`, `"r"`, or `"read,write,execute"`).
- `programs[]`: `id`, `path`, `description`, `defaultWorkingDirectory`, `fixedArguments`,
  `allowArgumentsFromClient`, `environment`, `timeoutSeconds`, `maxOutputBytes`, `sha256`,
  `acknowledgeInterpreter`.
- `pathFolders[]`, `tempDirectory`, `auditLogPath`.
- `defaultTimeoutSeconds`, `maxTimeoutSeconds`, `maxOutputBytes`, `allowHardLinkedFiles`.

`sha256` pins the image and is verified at start up and before every run. Leave it out for a
binary you rebuild often; `nsexec-mcp.exe --hash <file>` prints the value when you want it.

A configuration that does not validate stops the server at start up with exit code 3. There is no
degraded mode.

## Build

```
build.cmd
```

produces two executables in `publish\` (framework dependent, .NET 8, win-x64):

- `nsexec-mcp.exe` — the MCP server.
- `nsexec-mcp-config.exe` — the policy editor described below.

## The policy editor

A WinForms editor for the policy file, so the folders, the programs and the limits do not have to
be written by hand.

- **Folders** — the authorized folders. Read is always on; `Write` and `Execute` are checkboxes.
  `Execute` only means a whitelisted image may live there.
- **Programs** — one entry per whitelisted executable: id, image, description, default working
  folder, fixed arguments, whether the client may add arguments, the interpreter acknowledgement,
  per program timeout and output ceiling, environment variables, and a `Compute` button that fills
  the SHA-256 by calling `nsexec-mcp.exe --hash`.
- **General** — the limits, the audit log, the temp folder, the extra PATH folders, and the path
  of `nsexec-mcp.exe` itself. That last one is an editor preference, kept in
  `%APPDATA%\nsexec-mcp\config-ui.json`, not written into the policy.

**Validate policy** runs `nsexec-mcp.exe --check` against what is on screen — if there are unsaved
changes, a draft is written to the temp folder and that draft is validated — and shows the output
verbatim. The editor never reimplements the rules, so the two can never disagree about what is
allowed. **Probe a path** runs `--probe`, which is the quickest way to see what a `subst` drive or
a junction really resolves to. **Show MCP server entry** builds the `mcpServers` block with the
current paths, ready to copy.

Saving rewrites the file with the keys the editor knows. Comments in a hand written policy file are
read fine but are not preserved on save; the per folder `comment` field is.

## Check before connecting it

```
nsexec-mcp.exe --config <file> --check
nsexec-mcp.exe --config <file> --probe "X:\SaruEmu\src"
nsexec-mcp.exe --config <file> --call list_programs
nsexec-mcp.exe --config <file> --call run_program --json "{\"program\":\"nsc\",\"args\":[\"--version\"]}"
```

`--probe` prints each canonicalization step and the final verdict, which is the fastest way to see
what a `subst` drive or a junction really resolves to. All of this writes to stderr; stdout carries
the MCP protocol only.

## Connect it

Add it to the desktop app's MCP server configuration
(`config/claude_desktop_config.snippet.json`), using absolute paths:

```json
{
  "mcpServers": {
    "nsexec": {
      "command": "C:\\nsexec-mcp\\nsexec-mcp.exe",
      "args": ["--config", "C:\\nsexec-mcp\\nsexec-mcp.config.json"]
    }
  }
}
```

The server speaks newline delimited JSON-RPC 2.0 and answers `initialize`, `ping`, `tools/list`
and `tools/call`, negotiating protocol version `2025-06-18`, `2025-03-26` or `2024-11-05`.

## Verification status

Not verified: neither project has ever been compiled or run. They were written without a .NET SDK
available, so there is no build or test evidence behind them. Braces balance, one type per file,
the 120 column limit and the required `using` directives were checked mechanically; everything
else is unverified. Expect the first `build.cmd` to surface compile errors, and the editor layout
to need tuning once it is on screen.
